using Cititrans.Auth.Negocio.Configuracion;
using Microsoft.Extensions.DependencyInjection;

namespace Cititrans.Auth.Negocio
{
    public static class ServicesConfiguration
    {
        public static IServiceCollection ConfigurarNegocio(this IServiceCollection services)
        {
            services.AddNeConfiguracion();

            return services;
        }
    }
}