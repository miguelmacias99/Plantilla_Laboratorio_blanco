using Microsoft.Extensions.DependencyInjection;

namespace Cititrans.Auth.Negocio.Configuracion
{
    public static class ServiceConfiguration
    {
        public static IServiceCollection AddNeConfiguracion(this IServiceCollection services)
        {
            return services;
        }
    }
}