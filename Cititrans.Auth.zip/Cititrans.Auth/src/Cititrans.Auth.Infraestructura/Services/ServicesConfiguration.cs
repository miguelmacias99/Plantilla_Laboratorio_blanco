using Cititrans.Auth.Infraestructura.Services.Encriptacion;
using Cititrans.Auth.Infraestructura.Services.Redis;
using Microsoft.Extensions.DependencyInjection;

namespace Cititrans.Auth.Infraestructura.Services
{
    public static class ServicesConfiguration
    {
        public static IServiceCollection ConfigurarServiciosRedis(this IServiceCollection services)
        {
            services.AddScoped<IRedisCacheService, RedisCacheService>();

            return services;
        }

        public static IServiceCollection ConfigurarInfraestructura(this IServiceCollection services)
        {
            services.AddScoped<IEncriptarTextoService, EncriptarTextoService>();

            return services;
        }
    }
}