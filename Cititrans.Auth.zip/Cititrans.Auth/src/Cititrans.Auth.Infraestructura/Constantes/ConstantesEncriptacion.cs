namespace Cititrans.Auth.Infraestructura.Constantes
{
    public static class ConstantesEncriptacion
    {
        public static readonly string VectorInicial = "Encriptacion:IV";
        public static readonly string Key = "Encriptacion:Key";
    }
}