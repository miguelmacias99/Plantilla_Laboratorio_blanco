namespace Cititrans.Auth.Entidad.Interfaz
{
    public interface IUnidadTrabajo
    {
        void Begin();

        void Commit();

        void Rollback();
    }
}