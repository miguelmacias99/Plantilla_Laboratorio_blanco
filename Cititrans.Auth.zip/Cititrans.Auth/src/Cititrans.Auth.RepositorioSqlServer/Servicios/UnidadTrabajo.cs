using System.Data;
using Cititrans.Auth.Entidad.Interfaz;

namespace Cititrans.Auth.RepositorioEfCore.Servicios
{
    internal class UnidadTrabajo(IDbConnection connection) : IUnidadTrabajo
    {
        private readonly IDbConnection _connection = connection;
        private IDbTransaction _transaction = null!;

        public void Begin()
        {
            _connection.Open();
            _transaction = _connection.BeginTransaction();
        }

        public void Commit()
        {
            try
            {
                _transaction.Commit();
            }
            catch
            {
                _transaction.Rollback();
                throw;
            }
            finally
            {
                _connection.Close();
            }
        }

        public void Rollback()
        {
            _transaction?.Rollback();
            _connection.Close();
        }
    }
}