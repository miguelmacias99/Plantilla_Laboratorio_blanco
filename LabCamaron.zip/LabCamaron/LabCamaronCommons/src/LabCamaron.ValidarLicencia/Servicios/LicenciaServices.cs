﻿using LabCamaron.ValidarLicencia.Interfaces;
using LabCamaron.ValidarLicencia.Modelo;
using System.Net.NetworkInformation;
using System.Security.Cryptography;
using System.Text;

namespace LabCamaron.ValidarLicencia.Servicios
{
    internal class LicenciaServices : ILicenciaServices
    {
        private readonly string NombreLicencia = "licencia.lic";
        public ValidezLicencia VerificarLicencia(string key, string iv)
        {
            try
            {
                var rutaLicencia = Path.Combine(Directory.GetCurrentDirectory(), NombreLicencia);
                if (!File.Exists(rutaLicencia))
                {
                    return new()
                    {
                        EsValida = false,
                        Mensaje = "No se encontró una licencia válida en la ruta: " + rutaLicencia,
                    };
                }

                using Aes aesAlg = Aes.Create();
                aesAlg.Key = Convert.FromBase64String(key);
                aesAlg.IV = Convert.FromBase64String(iv);

                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);
                using FileStream fileStream = new(rutaLicencia, FileMode.Open);
                using CryptoStream cryptoStream = new(fileStream, decryptor, CryptoStreamMode.Read);
                using StreamReader reader = new(cryptoStream);
                var licenciaBase64 = reader.ReadToEnd();
                var licenciaByte = Convert.FromBase64String(licenciaBase64);
                var datosTextoLicencia = Encoding.UTF8.GetString(licenciaByte);
                var datosLicencia = datosTextoLicencia.Split("|");

                if (!DateTime.TryParse(datosLicencia[^1], out var fechaValidez))
                {
                    return new()
                    {
                        EsValida = false,
                        Mensaje = "No se pudo leer la fecha de validez de la licencia"
                    };
                }

                if (fechaValidez < DateTime.Now)
                {
                    return new()
                    {
                        EsValida = false,
                        Mensaje = "La licencia ha expirado"
                    };
                }

                var macAddress = ObtenerDireccionMac();
                if (macAddress.Count != datosLicencia.Length - 1)
                {
                    return new()
                    {
                        EsValida = false,
                        Mensaje = "La licencia es inválida"
                    };
                }

                for (int i = 0; i < macAddress.Count; i++)
                {
                    if (!datosLicencia.Contains(macAddress[i]))
                    {
                        return new()
                        {
                            EsValida = false,
                            Mensaje = "La licencia es inválida"
                        };
                    }
                }


                return new()
                {
                    EsValida = true,
                    Mensaje = "Licencia válida"
                };
            }
            catch (Exception ex)
            {
                return new()
                {
                    EsValida = true,
                    Mensaje = "Ha ocurrido un error. " + ex.Message
                };
            }
        }

        private static List<string> ObtenerDireccionMac()
        {
            // Obtener todas las interfaces de red en el sistema
            NetworkInterface[] networkInterfaces = [.. NetworkInterface.GetAllNetworkInterfaces().OrderBy(e => e.Name)];

            List<string> macAddressStr = [];
            foreach (NetworkInterface ni in networkInterfaces)
            {
                // Verifica que la interfaz esté habilitada y no sea de tipo loopback
                if (ni.OperationalStatus == OperationalStatus.Up && ni.NetworkInterfaceType != NetworkInterfaceType.Loopback)
                {
                    // Obtener la dirección MAC
                    PhysicalAddress macAddress = ni.GetPhysicalAddress();
                    byte[] macAddr = macAddress.GetAddressBytes();

                    // Convertir la dirección MAC a formato legible
                    macAddressStr.Add(string.Join(":", macAddr.Select(b => b.ToString("X2"))));
                }
            }

            return macAddressStr;
        }

    }
}
