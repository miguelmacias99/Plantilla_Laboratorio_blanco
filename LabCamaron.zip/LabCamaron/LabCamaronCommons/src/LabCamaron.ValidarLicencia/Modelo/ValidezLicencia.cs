﻿namespace LabCamaron.ValidarLicencia.Modelo
{
    public class ValidezLicencia
    {
        public string Mensaje { get; set; } = null!;
        public bool EsValida { get; set; }
    }
}
