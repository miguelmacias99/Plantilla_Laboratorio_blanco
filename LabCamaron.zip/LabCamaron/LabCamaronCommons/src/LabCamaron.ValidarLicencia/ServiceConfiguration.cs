﻿using LabCamaron.ValidarLicencia.Interfaces;
using LabCamaron.ValidarLicencia.Servicios;
using Microsoft.Extensions.DependencyInjection;

namespace LabCamaron.ValidarLicencia
{
    public static class ServiceConfiguration
    {
        public static IServiceCollection ConfigurarLicencia(this IServiceCollection services)
        {
            services.AddScoped<ILicenciaServices, LicenciaServices>();
            return services;
        }
    }
}
