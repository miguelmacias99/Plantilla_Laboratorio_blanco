﻿using LabCamaron.ValidarLicencia.Modelo;

namespace LabCamaron.ValidarLicencia.Interfaces
{
    public interface ILicenciaServices
    {
        ValidezLicencia VerificarLicencia(string key, string iv);
    }
}
