using Microsoft.Extensions.DependencyInjection;
using LabCamaronWeb.Infraestructura.Utilidades;

namespace LabCamaronWeb.Infraestructura
{
    public static class ServicesConfiguration
    {
        public static IServiceCollection RegistrarInfraestructura(this IServiceCollection services)
        {
            services.ConfigurarUtilidades();
            return services;
        }
    }
}
