using Microsoft.Extensions.DependencyInjection;
using LabCamaronWeb.Infraestructura.Utilidades.Http;

namespace LabCamaronWeb.Infraestructura.Utilidades
{
    public static class ServicesConfiguration
    {
        public static IServiceCollection ConfigurarUtilidades(this IServiceCollection services)
        {
            services.AddScoped<IOperacionHttpServicio, OperacionHttpServicio>();
            return services;
        }
    }
}
