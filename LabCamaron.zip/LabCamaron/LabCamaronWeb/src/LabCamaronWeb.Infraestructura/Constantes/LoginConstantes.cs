﻿namespace LabCamaronWeb.Infraestructura.Constantes
{
    public static class LoginConstantes
    {
        public static readonly string TipoMensajeLogin = "TipoMensaje";
        public static readonly string TipoCambioClave = "CambioClave";
    }
}
