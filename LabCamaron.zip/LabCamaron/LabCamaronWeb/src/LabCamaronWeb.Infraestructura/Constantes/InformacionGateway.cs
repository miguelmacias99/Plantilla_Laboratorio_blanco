namespace LabCamaronWeb.Infraestructura.Constantes
{
    public static class InformacionGateway
    {
        public const string Nombre = "GatewayUri";
    }
}
