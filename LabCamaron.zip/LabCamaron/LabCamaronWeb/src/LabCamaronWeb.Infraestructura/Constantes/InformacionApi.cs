namespace LabCamaronWeb.Infraestructura.Constantes
{
    public static class InformacionApi
    {
        public static string Nombre { get; set; } = null!;
    }
}
