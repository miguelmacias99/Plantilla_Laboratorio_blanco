﻿namespace LabCamaronWeb.Infraestructura.Constantes.Menus
{
    public static class PermisoGeneral
    {
        public const string Ver = "VER";
    }
}
