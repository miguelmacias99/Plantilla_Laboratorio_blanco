using LabCamaronWeb.Infraestructura.Modelo;
using System.Runtime.CompilerServices;

namespace LabCamaronWeb.Dto.Configuracion.Rol
{
    public class RespuestaConsultaRolVm
    {
        public RespuestaGenericaVm Respuesta { get; set; } = null!;
        public RolVm? Rol { get; set; }

        public RespuestaConsultaRolVm()
        {
        }
        public RespuestaConsultaRolVm(string codigo, string mensaje, [CallerMemberName] string metodoInvoca = "")
        {
            Respuesta = new RespuestaGenericaVm(codigo, mensaje, metodoInvoca);
        }
        public RespuestaConsultaRolVm(RespuestaGenericaVm respuesta)
        {
            Respuesta = respuesta;
        }
    }
}