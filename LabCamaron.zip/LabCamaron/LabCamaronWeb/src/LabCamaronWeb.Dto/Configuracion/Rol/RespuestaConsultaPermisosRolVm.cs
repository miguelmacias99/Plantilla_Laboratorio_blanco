﻿using LabCamaronWeb.Infraestructura.Modelo;
using System.Runtime.CompilerServices;

namespace LabCamaronWeb.Dto.Configuracion.Rol
{
    public class RespuestaConsultaPermisosRolVm
    {
        public RespuestaGenericaVm Respuesta { get; set; } = null!;
        public PermisoRolVm? Permisos { get; set; }

        public RespuestaConsultaPermisosRolVm()
        {
        }

        public RespuestaConsultaPermisosRolVm(string codigo, string mensaje, [CallerMemberName] string metodoInvoca = "")
        {
            Respuesta = new RespuestaGenericaVm(codigo, mensaje, metodoInvoca);
        }
        public RespuestaConsultaPermisosRolVm(RespuestaGenericaVm respuesta)
        {
            Respuesta = respuesta;
        }
    }
}
