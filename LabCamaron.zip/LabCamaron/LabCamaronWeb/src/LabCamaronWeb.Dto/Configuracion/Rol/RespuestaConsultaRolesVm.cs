using LabCamaronWeb.Infraestructura.Modelo;
using System.Runtime.CompilerServices;

namespace LabCamaronWeb.Dto.Configuracion.Rol
{
    public class RespuestaConsultaRolesVm
    {
        public RespuestaGenericaVm Respuesta { get; set; } = null!;
        public List<RolVm>? Roles { get; set; }

        public RespuestaConsultaRolesVm()
        {
        }
        public RespuestaConsultaRolesVm(string codigo, string mensaje, [CallerMemberName] string metodoInvoca = "")
        {
            Respuesta = new RespuestaGenericaVm(codigo, mensaje, metodoInvoca);
        }
        public RespuestaConsultaRolesVm(RespuestaGenericaVm respuesta)
        {
            Respuesta = respuesta;
        }
    }
}