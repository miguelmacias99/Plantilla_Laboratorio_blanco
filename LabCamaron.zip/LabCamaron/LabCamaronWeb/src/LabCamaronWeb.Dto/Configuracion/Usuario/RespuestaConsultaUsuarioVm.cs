﻿using LabCamaronWeb.Infraestructura.Modelo;
using System.Runtime.CompilerServices;

namespace LabCamaronWeb.Dto.Configuracion.Usuario
{
    public class RespuestaConsultaUsuarioVm
    {
        public RespuestaGenericaVm Respuesta { get; set; } = null!;
        public UsuarioVm? Usuario { get; set; }

        public RespuestaConsultaUsuarioVm()
        {

        }
        public RespuestaConsultaUsuarioVm(RespuestaGenericaVm respuesta)
        {
            Respuesta = respuesta;
        }
        public RespuestaConsultaUsuarioVm(string codigo, string mensaje, [CallerMemberName] string metodoInvoca = "")
        {
            Respuesta = new RespuestaGenericaVm(codigo, mensaje, metodoInvoca);
        }
    }
}
