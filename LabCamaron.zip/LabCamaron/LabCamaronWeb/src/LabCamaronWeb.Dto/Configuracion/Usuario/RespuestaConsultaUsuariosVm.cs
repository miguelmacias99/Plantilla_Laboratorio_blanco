﻿using LabCamaronWeb.Infraestructura.Modelo;
using System.Runtime.CompilerServices;
using static LabCamaronWeb.Dto.Configuracion.Login.PermisoUsuarioVm;

namespace LabCamaronWeb.Dto.Configuracion.Usuario
{
    public class RespuestaConsultaUsuariosVm
    {
        public RespuestaGenericaVm Respuesta { get; set; } = null!;
        public List<UsuarioVm>? Usuarios { get; set; }
        public RespuestaConsultaUsuariosVm()
        {

        }
        public RespuestaConsultaUsuariosVm(RespuestaGenericaVm respuesta)
        {
            Respuesta = respuesta;
        }
        public RespuestaConsultaUsuariosVm(string codigo, string mensaje, [CallerMemberName] string metodoInvoca = "")
        {
            Respuesta = new RespuestaGenericaVm(codigo, mensaje, metodoInvoca);
        }
    }
}
