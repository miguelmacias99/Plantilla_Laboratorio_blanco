﻿using LabCamaronWeb.Dto.Configuracion.Rol;
using LabCamaronWeb.Infraestructura.Modelo;
using static LabCamaronWeb.Dto.Configuracion.Rol.RolVm;

namespace LabCamaronWeb.Servicios.Configuracion.Interfaces
{
    public interface ISeRolService
    {
        Task<RespuestaConsultaRolVm> ConsultarPorId(ConsultarRol consultar);
        Task<RespuestaConsultaRolesVm> ConsultarTodos(ConsultarTodosRol consultar);
        Task<RespuestaGenericaVm> Crear(CrearRol crear);
        Task<RespuestaGenericaVm> Actualizar(ActualizarRol actualizar);
        Task<RespuestaGenericaVm> Eliminar(EliminarRol eliminar);
        Task<RespuestaConsultaPermisosRolVm> ConsultarPermisos(PermisoRolVm.Consultar consultar);
        Task<RespuestaGenericaVm> ActualizarPermisos(PermisoRolVm.Actualizar actualizar);
    }
}
