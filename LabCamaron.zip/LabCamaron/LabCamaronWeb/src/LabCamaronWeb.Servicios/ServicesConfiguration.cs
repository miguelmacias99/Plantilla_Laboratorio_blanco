using Microsoft.Extensions.DependencyInjection;
using LabCamaronWeb.Servicios.Configuracion;

namespace LabCamaronWeb.Servicios
{
    public static class ServicesConfiguration
    {
        public static IServiceCollection RegistrarServicios(this IServiceCollection services)
        {
            services.RegistrarServiciosConfiguracion();

            return services;
        }
    }
}
