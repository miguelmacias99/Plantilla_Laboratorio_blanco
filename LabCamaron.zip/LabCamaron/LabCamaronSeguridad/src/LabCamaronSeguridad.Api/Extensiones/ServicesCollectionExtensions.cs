using LabCamaron.ValidarLicencia;
using LabCamaron.ValidarLicencia.Interfaces;
using LabCamaronSeguridad.Infraestructura.Constantes;
using LabCamaronSeguridad.Infraestructura.Utilidades.Logger;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Serilog;
using Serilog.Events;
using StackExchange.Redis;
using System.ComponentModel;
using System.Text;

namespace LabCamaronSeguridad.Api.Extensiones
{
    public static class ServicesCollectionExtensions
    {
        public static IServiceCollection ConfigurarSerilog(
            this IServiceCollection servicesollection, WebApplicationBuilder builder)
        {
            var urlSeq = builder.Configuration["SeqUrl"]!;

            var logger = new LoggerConfiguration()
                .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
                .MinimumLevel.Override("Microsoft.Hosting.LifeTime", LogEventLevel.Warning)
                .MinimumLevel.Override("Microsoft.AspNetCore.StaticFiles", LogEventLevel.Warning)
                .MinimumLevel.Override("Microsoft.AspNetCore.EntityFrameWork.Database", LogEventLevel.Warning)
                .Enrich.FromLogContext()
                .Enrich.WithEnvironmentName()
                .Enrich.WithMachineName()
                .Enrich.WithEnvironmentUserName()
                .Enrich.WithProperty("NombreAplicacion", InformacionApi.Nombre)
                .Enrich.WithCorrelationId()
                .WriteTo.Console(LogEventLevel.Information)
                .WriteTo.Async(s => s.Seq(urlSeq));

            Log.Logger = logger.CreateLogger();
            builder.Host.UseSerilog(Log.Logger);
            servicesollection.AddSingleton(Log.Logger);

            var messageTemplate = $"{InformacionApi.Nombre} Iniciada!!";
            Log.Logger.Information(messageTemplate);

            return servicesollection;
        }

        public static IServiceCollection ConfigurarAutenticacion(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(options =>
            {
                options.SaveToken = true;
                options.RequireHttpsMetadata = false;
                options.TokenValidationParameters = new TokenValidationParameters()
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ClockSkew = TimeSpan.Zero,

                    ValidAudiences = configuration["JWT:ValidAudience"]!.Split(","),
                    ValidIssuer = configuration["JWT:ValidIssuer"],
                    IssuerSigningKey = new SymmetricSecurityKey(configuration.GetJwtSecretFromServices())
                };
            });

            return services;
        }

        public static IServiceCollection ConfigurarRedis(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSingleton<IConnectionMultiplexer>(
                ConnectionMultiplexer.Connect(configuration.GetValue<string>("Redis:Url")!));

            services.AddStackExchangeRedisCache(options =>
            {
                options.Configuration = configuration.GetValue<string>("Redis:Url");
            });

            return services;
        }

        public static IServiceCollection ConfigurarSesion(this IServiceCollection services)
        {
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            return services;
        }
        private static byte[] GetJwtSecretFromServices(this IConfiguration configuration)
        {
            return Encoding.UTF8.GetBytes(configuration["JWT:Secret"]!);
        }
        public static IApplicationBuilder AgregarOperacionesApi(this IApplicationBuilder application, string ambiente)
        {
            application.UseEndpoints(delegate (IEndpointRouteBuilder endpoints)
            {
                endpoints.MapControllers();
                endpoints.MapGet("/", async delegate (HttpContext context)
                {
                    await context.Response.WriteAsync(InformacionApi.Nombre + " " + ambiente + " Trabajando!!");
                });
            });
            return application;
        }

        public static bool ValidarLicencia(this IServiceCollection services, IConfiguration configuration)
        {
            services.ConfigurarLicencia();
            var serviceProvider = services.BuildServiceProvider();

            // Obt�n una instancia de ILicenciaServices
            var licenciaServices = serviceProvider.GetService<ILicenciaServices>();

            var respuesta = licenciaServices!.VerificarLicencia(configuration["Seguridad:Key"]!, configuration["Seguridad:Inicializador"]!);
            if (!respuesta.EsValida)
            {
                var messageTemplate = $"{InformacionApi.Nombre} Error - {respuesta.Mensaje}";
                Log.Logger.Error(messageTemplate);
                return false; 
            }

            return true;
        }
    }
}