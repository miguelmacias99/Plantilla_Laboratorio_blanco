using LabCamaronSeguridad.Api.Extensiones;
using LabCamaronSeguridad.Api.Middleware;
using LabCamaronSeguridad.Infraestructura.Constantes;
using LabCamaronSeguridad.Infraestructura.Services;
using LabCamaronSeguridad.Negocio;
using LabCamaronSeguridad.RepositorioSqlServer;
using Microsoft.AspNetCore.Mvc;
using Serilog;
using System.Reflection;

var builder = WebApplication.CreateBuilder(args);

InformacionApi.Nombre = Assembly.GetExecutingAssembly().GetName().Name!;

// Add services to the container.
string connectionString = builder.Configuration.GetConnectionString("DefaultConnection")!;
builder.Services.AddControllers();
builder.Services.Configure<ApiBehaviorOptions>(options => options.SuppressModelStateInvalidFilter = true);

// Adding Authentication
builder.Services.ConfigurarAutenticacion(builder.Configuration);
builder.Services.ConfigurarRedis(builder.Configuration);
builder.Services.AddDistributedMemoryCache();
builder.Services.ConfigurarSesion();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.ConfigurarSerilog(builder);
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.ConfigurarBaseDatos(connectionString);
builder.Services.ConfigurarRepositorioSqlServer();
builder.Services.ConfigurarInfraestructura();
builder.Services.ConfigurarNegocio();

//if (!builder.Services.ValidarLicencia(builder.Configuration)) return;

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseRouting();
app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();
app.UseMiddleware<LogMiddleware>();
app.AgregarOperacionesApi(builder.Environment.EnvironmentName);
app.MapControllers();

await app.RunAsync();