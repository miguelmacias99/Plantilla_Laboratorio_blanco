using LabCamaronSeguridad.Infraestructura.Utilidades.Logger;
using LabCamaronSeguridad.Negocio.Configuracion.Usuario;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using static LabCamaronSeguridad.Dto.Modelo.Configuracion.Usuario.UsuarioDto;

namespace LabCamaronSeguridad.Api.Controllers.Configuracion
{
    [ApiController]
    [Route("api/v1")]
    public class UsuarioController(INeUsuario neUsuario) : ControllerBase
    {
        private readonly INeUsuario neUsuario = neUsuario;

        [Authorize]
        [HttpPost("crear-usuario")]
        public async Task<IActionResult> CrearUsuario(CrearUsuario crear)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var respuesta = await neUsuario.CrearUsuario(crear);

                return respuesta.ExisteExcepcion
                    ? StatusCode((int)HttpStatusCode.InternalServerError, respuesta)
                    : Ok(respuesta);
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, crear);
                return StatusCode((int)HttpStatusCode.InternalServerError, "Ha ocurrido un error");
            }
        }
        
        [Authorize]
        [HttpPost("consultar-usuario")]
        public async Task<IActionResult> ConsultarUsuario(ConsultarUsuario consultar)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var respuesta = await neUsuario.ConsultarUsuario(consultar);

                return respuesta.Respuesta.ExisteExcepcion
                    ? StatusCode((int)HttpStatusCode.InternalServerError, respuesta)
                    : Ok(respuesta);
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, consultar);
                return StatusCode((int)HttpStatusCode.InternalServerError, "Ha ocurrido un error");
            }
        }
        
        [Authorize]
        [HttpPost("consultar-usuarios")]
        public async Task<IActionResult> ConsultarUsuarios(ConsultarTodos consultar)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var respuesta = await neUsuario.ConsultarUsuarios(consultar);

                return respuesta.Respuesta.ExisteExcepcion
                    ? StatusCode((int)HttpStatusCode.InternalServerError, respuesta)
                    : Ok(respuesta);
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, consultar);
                return StatusCode((int)HttpStatusCode.InternalServerError, "Ha ocurrido un error");
            }
        }
        
        [Authorize]
        [HttpPost("actualizar-usuario")]
        public async Task<IActionResult> ActualizarUsuario(ActualizarUsuario actualizar)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var respuesta = await neUsuario.ActualizarUsuario(actualizar);

                return respuesta.ExisteExcepcion
                    ? StatusCode((int)HttpStatusCode.InternalServerError, respuesta)
                    : Ok(respuesta);
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, actualizar);
                return StatusCode((int)HttpStatusCode.InternalServerError, "Ha ocurrido un error");
            }
        }

        [Authorize]
        [HttpPost("actualizar-clave-usuario")]
        public async Task<IActionResult> ActualizarClaveUsuario(ActualizarClaveUsuario actualizar)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var respuesta = await neUsuario.ActualizarClaveUsuario(actualizar);

                return respuesta.ExisteExcepcion
                    ? StatusCode((int)HttpStatusCode.InternalServerError, respuesta)
                    : Ok(respuesta);
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, actualizar);
                return StatusCode((int)HttpStatusCode.InternalServerError, "Ha ocurrido un error");
            }
        }

        [Authorize]
        [HttpPost("reestablecer-clave-usuario")]
        public async Task<IActionResult> ReestablecerClaveUsuario(ReestablecerContrasenia request)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var respuesta = await neUsuario.ReestablecerContrasenia(request);

                return respuesta.ExisteExcepcion
                    ? StatusCode((int)HttpStatusCode.InternalServerError, respuesta)
                    : Ok(respuesta);
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, request);
                return StatusCode((int)HttpStatusCode.InternalServerError, "Ha ocurrido un error");
            }
        }

        [Authorize]
        [HttpPost("actualizar-rol-usuario")]
        public async Task<IActionResult> ActualizarRolesUsuario(ActualizarRolUsuario request)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var respuesta = await neUsuario.ActualizarRolesUsuario(request);

                return respuesta.ExisteExcepcion
                    ? StatusCode((int)HttpStatusCode.InternalServerError, respuesta)
                    : Ok(respuesta);
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, request);
                return StatusCode((int)HttpStatusCode.InternalServerError, "Ha ocurrido un error");
            }
        }

        [Authorize]
        [HttpPost("eliminar-usuario")]
        public async Task<IActionResult> EliminarUsuario(EliminarUsuario request)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var respuesta = await neUsuario.EliminarUsuario(request);

                return respuesta.ExisteExcepcion
                    ? StatusCode((int)HttpStatusCode.InternalServerError, respuesta)
                    : Ok(respuesta);
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, request);
                return StatusCode((int)HttpStatusCode.InternalServerError, "Ha ocurrido un error");
            }
        }
    }
}