using LabCamaronSeguridad.Dto.Modelo.Configuracion.Login;
using LabCamaronSeguridad.Infraestructura.Utilidades.Logger;
using LabCamaronSeguridad.Negocio.Configuracion.Login;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace LabCamaronSeguridad.Api.Controllers.Login
{
    [ApiController]
    [Route("api/v1")]
    public class LoginController(INeLogin neLogin) : ControllerBase
    {
        private readonly INeLogin neLogin = neLogin;

        [HttpPost("iniciar-sesion")]
        public async Task<IActionResult> IniciarSesion(LoginDto login)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var consulta = await neLogin.Login(login);

                return consulta.Respuesta.ExisteExcepcion
                    ? StatusCode((int)HttpStatusCode.InternalServerError, consulta)
                    : Ok(consulta);
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, login);
                return StatusCode((int)HttpStatusCode.InternalServerError, "Ha ocurrido un error");
            }
        }


        [Authorize]
        [HttpPost("validar-autorizacion")]
        public async Task<IActionResult> ValidarAutorizacion(DetallePermisoDto.AutorizarAccion autorizar)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var respuestaAutorizar = await neLogin.AutorizarAccion(autorizar);

                return respuestaAutorizar.Respuesta.ExisteExcepcion
                    ? base.StatusCode((int)HttpStatusCode.InternalServerError, (object)autorizar)
                    : base.Ok((object)respuestaAutorizar);
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, autorizar);
                return StatusCode((int)HttpStatusCode.InternalServerError, "Ha ocurrido un error");
            }
        }


        [Authorize]
        [HttpPost("obtener-permisos-sesion")]
        public async Task<IActionResult> ObtenerPermisosSesion(DetallePermisoDto.ConsultarPermisos consultar)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var respuestaPermisoSesion = await neLogin.ObtenerPermisosSesion(consultar);

                return respuestaPermisoSesion.Respuesta.ExisteExcepcion
                    ? base.StatusCode((int)HttpStatusCode.InternalServerError, (object)consultar)
                    : base.Ok((object)respuestaPermisoSesion);
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, consultar);
                return StatusCode((int)HttpStatusCode.InternalServerError, "Ha ocurrido un error");
            }
        }
    }
}