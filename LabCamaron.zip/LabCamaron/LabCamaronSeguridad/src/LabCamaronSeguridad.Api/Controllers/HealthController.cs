using Microsoft.AspNetCore.Mvc;

namespace LabCamaronSeguridad.Api.Controllers
{
    [ApiController]
    [Route("api/v1")]
    public class HealthController : ControllerBase
    {
        [HttpGet("seguridades-health-check")]
        [ProducesResponseType<string>(StatusCodes.Status200OK)]
        public IActionResult CheckHealth() => Ok("ready");
    }
}