using LabCamaronSeguridad.Entidad.Interfaz;
using LabCamaronSeguridad.RepositorioSqlServer.Servicios;
using LabCamaronSeguridad.RepositorioSqlServer.Servicios.Configuracion;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.DependencyInjection;
using System.Data;

namespace LabCamaronSeguridad.RepositorioSqlServer
{
    public static class ServicesConfiguration
    {
        public static IServiceCollection ConfigurarBaseDatos(this IServiceCollection services, string cadenaConexion)
        {
            services.AddScoped<IDbConnection>(db => new SqlConnection(cadenaConexion));
            services.AddScoped<IDbTransaction>(s =>
            {
                SqlConnection conn = s.GetRequiredService<SqlConnection>();
                conn.Open();
                return conn.BeginTransaction();
            });
            return services;
        }

        public static IServiceCollection ConfigurarRepositorioSqlServer(this IServiceCollection services)
        {
            services.AddServiciosConfiguracion();
            services.AddScoped<IUnidadTrabajo, UnidadTrabajo>();

            return services;
        }
    }
}