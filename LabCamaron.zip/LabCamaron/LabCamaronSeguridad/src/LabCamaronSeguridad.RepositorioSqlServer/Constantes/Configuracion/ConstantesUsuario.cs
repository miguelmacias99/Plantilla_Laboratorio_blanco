namespace LabCamaronSeguridad.RepositorioSqlServer.Constantes.Configuracion
{
    public static class ConstantesUsuario
    {
        public static readonly string ProcedimientoConsultarPorCodigo = "CONSULTAR_USUARIO_CODIGO";
        public static readonly string ProcedimientoConsultarPermisoPorId = "CONSULTAR_PERMISO_USUARIO_ID";
        public static readonly string ProcedimientoConsultarRolPorId = "CONSULTAR_ROL_USUARIO_ID";
        public static readonly string ProcedimientoCrearUsuario = "CREAR_USUARIO";
        public static readonly string ProcedimientoEliminarUsuario = "ELIMINAR_USUARIO";
        public static readonly string ProcedimientoActualizarUsuario = "ACTUALIZAR_USUARIO";
        public static readonly string ProcedimientoActualizarContraseniaUsuario = "ACTUALIZAR_CLAVE_USUARIO";
        public static readonly string ProcedimientoConsultarDetallePermisoUsuario = "CONSULTAR_DETALLE_PERMISO_USUARIO";
        public static readonly string ProcedimientoConsultarUsuarios = "CONSULTAR_USUARIOS";
        public static readonly string ProcedimientoConsultarRolesPermitidosUsuarios = "CONSULTAR_ROLES_PERMITIDO_USUARIO";
        public static readonly string ActualizarRolesUsuario = "ACTUALIZAR_ROLES_USUARIO";

        public static readonly string Id = "@Id";
        public static readonly string Codigo = "@Codigo";
        public static readonly string Descripcion = "@Descripcion";
        public static readonly string Tipo = "@Tipo";
        public static readonly string ActualizarContrasenia = "@ActualizarContrasenia";
        public static readonly string FechaValidezContrasenia = "@FechaValidezContrasenia";
        public static readonly string HashContrasenia = "@HashContrasenia";
        public static readonly string SaltContrasenia = "@SaltContrasenia";

        public static readonly string IdUsuario = "@IdUsuario";
        public static readonly string CodigoUsuario = "@CodigoUsuario";
        public static readonly string SoloActivos = "@SoloActivos";
        public static readonly string RolesUsuario = "@RolesUsuario";
    }
}