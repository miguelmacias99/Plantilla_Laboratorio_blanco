namespace LabCamaronSeguridad.RepositorioSqlServer.Constantes.Configuracion
{
    public static class ConstantesRol
    {
        public static readonly string ProcedimientoConsultarPorCodigo = "CONSULTAR_ROL_CODIGO";
        public static readonly string ProcedimientoConsultarTodos = "CONSULTAR_ROLES";
        public static readonly string ProcedimientoCrearRol = "CREAR_ROL";
        public static readonly string ProcedimientoEliminarRol = "ELIMINAR_ROL";
        public static readonly string ProcedimientoActualizarRol = "ACTUALIZAR_ROL";
        public static readonly string ProcedimientoConsultarPermisosRol = "CONSULTAR_PERMISOS_ROL";
        public static readonly string ProcedimientoActualizarPermisosRol = "ACTUALIZAR_PERMISOS_ROL";

        public static readonly string Id = "@Id";
        public static readonly string Codigo = "@Codigo";
        public static readonly string Nombre = "@Nombre";
        public static readonly string Descripcion = "@Descripcion";
        public static readonly string SoloActivos = "@SoloActivos";

        public static readonly string CodigoRol = "@CodigoRol";
        public static readonly string ListaPermisos = "@ListaPermisos";
    }
}