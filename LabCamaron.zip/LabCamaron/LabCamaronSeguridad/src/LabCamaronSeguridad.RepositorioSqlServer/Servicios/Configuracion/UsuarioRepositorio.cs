using Dapper;
using LabCamaronSeguridad.Entidad.Interfaz.Configuracion;
using LabCamaronSeguridad.Entidad.Modelo.Configuracion;
using LabCamaronSeguridad.Infraestructura.Constantes;
using LabCamaronSeguridad.Infraestructura.Extensiones.Dapper;
using LabCamaronSeguridad.Infraestructura.Modelo;
using LabCamaronSeguridad.Infraestructura.Services.Sesion;
using LabCamaronSeguridad.RepositorioSqlServer.Constantes.Configuracion;
using System.Data;
using static LabCamaronSeguridad.Entidad.Modelo.Configuracion.PermisoUsuario;
using static LabCamaronSeguridad.Entidad.Modelo.Configuracion.Usuario;

namespace LabCamaronSeguridad.RepositorioSqlServer.Servicios.Configuracion
{
    internal class UsuarioRepositorio(IDbConnection connection, IDbTransaction transaction,
        ISesionManager sesionManager) : IUsuarioRepositorio
    {
        private readonly IDbConnection _connection = connection;
        private readonly IDbTransaction _transaction = transaction;
        private readonly ISesionManager sesionManager = sesionManager;

        public async Task<Usuario?> ObtenerUsuario(string codigo)
        {
            var parametros = new DynamicParameters();
            parametros.ParametroEntrada(ConstantesUsuario.Codigo, codigo);

            return await _connection
                .QueryFirstOrDefaultAsync<Usuario?>(ConstantesUsuario.ProcedimientoConsultarPorCodigo, parametros, commandType: CommandType.StoredProcedure);
        }

        public async Task<PermisoUsuario> ObtenerPermisos(long idUsuario)
        {
            // Inicializamos los par�metros de la consulta
            var parametros = new DynamicParameters();
            parametros.Add(ConstantesUsuario.Id, idUsuario);

            var modulosDict = new Dictionary<long, Modulo>();

            // Ejecutamos la consulta y mapeamos los resultados
            var retorno = await _connection.QueryAsync<Modulo, Menu, Permiso, Modulo>(
                ConstantesUsuario.ProcedimientoConsultarPermisoPorId,
                (modulo, menu, permiso) =>
                {
                    // Inicializamos las colecciones si son null
                    if (!modulosDict.TryGetValue(modulo.Id, out Modulo? value))
                    {
                        // Inicializar listas si no existe el m�dulo
                        modulo.Menus = [];
                        value = modulo;
                        modulosDict[modulo.Id] = value;
                    }

                    // Evitar repetici�n de Men�s dentro del M�dulo
                    var menuExistente = value.Menus.FirstOrDefault(m => m.Id == menu.Id);
                    if (menuExistente == null)
                    {
                        menu.Permisos = []; // Inicializamos la lista de permisos si no existe
                        value.Menus.Add(menu);
                        menuExistente = menu; // Usamos el nuevo men�
                    }

                    // Evitar repetici�n de Permisos dentro del Men�
                    if (menuExistente.Permisos.All(p => p.Id != permiso.Id))
                    {
                        menuExistente.Permisos.Add(permiso); // Agregar el permiso al men�
                    }

                    return new(); // Devolvemos un new ya que no necesitamos un valor de retorno en este caso
                },
                splitOn: ConstantesRepositorio.SplitId,
                param: parametros,
                commandType: CommandType.StoredProcedure
            );

            // Devolvemos el resultado agrupado en un objeto de tipo PermisoUsuario
            return new PermisoUsuario
            {
                Modulos = [.. modulosDict.Values]  // Convertimos el IEnumerable a una lista
            };
        }

        public async Task<IEnumerable<PermisoUsuario.Rol>> ObtenerRolesUsuario(long idUsuario)
        {
            var parametros = new DynamicParameters();
            parametros.Add(ConstantesUsuario.Id, idUsuario);

            return await _connection.QueryAsync<PermisoUsuario.Rol>(ConstantesUsuario.ProcedimientoConsultarRolPorId,
                param: parametros, commandType: CommandType.StoredProcedure);
        }

        public async Task<(RespuestaGenericaDto respuesta, long id)> CrearUsuario(Crear crear)
        {
            // Configuramos los paramatros de entrada y salida
            var parametros = new DynamicParameters();
            parametros.ParametroEntrada(ConstantesUsuario.Codigo, crear.Codigo)
                .ParametroEntrada(ConstantesUsuario.Descripcion, crear.Descripcion)
                .ParametroEntrada(ConstantesUsuario.Tipo, crear.Tipo)
                .ParametroEntrada(ConstantesUsuario.ActualizarContrasenia, crear.ActualizarContrasenia)
                .ParametroEntrada(ConstantesUsuario.HashContrasenia, crear.HashContrasenia)
                .ParametroEntrada(ConstantesUsuario.SaltContrasenia, crear.SaltContrasenia)
                .ParametroEntradaUsuarioSesion(sesionManager.ObtenerUsuarioSesion())
                .ParametroSalidaLong(ConstantesUsuario.Id)
                .ParametroSalidaRespuestaDto();

            await _connection
                .ExecuteAsync(ConstantesUsuario.ProcedimientoCrearUsuario, parametros, _transaction, commandType: CommandType.StoredProcedure);

            // Generamos los parametros de salida
            long id = parametros.ParametroSalidaValor<long>(ConstantesUsuario.Id);
            var respuestaDto = parametros.ObtenerRespuestaDto();

            return (respuestaDto, id);
        }

        public async Task<RespuestaGenericaDto> ActualizarClaveUsuario(ActualizarClave actualizar)
        {
            // Configuramos los paramatros de entrada y salida
            var parametros = new DynamicParameters();
            parametros.ParametroEntrada(ConstantesUsuario.Id, actualizar.Id)
                .ParametroEntrada(ConstantesUsuario.HashContrasenia, actualizar.HashContrasenia)
                .ParametroEntrada(ConstantesUsuario.SaltContrasenia, actualizar.SaltContrasenia)
                .ParametroEntradaUsuarioSesion(sesionManager.ObtenerUsuarioSesion())
                .ParametroSalidaRespuestaDto();

            await _connection
                .ExecuteAsync(ConstantesUsuario.ProcedimientoActualizarContraseniaUsuario, parametros, _transaction, commandType: CommandType.StoredProcedure);

            return parametros.ObtenerRespuestaDto();
        }

        public async Task<IEnumerable<DetallePermiso>> ObtenerDetallesPermisosUsuario(string codigoUsuario)
        {
            var parametros = new DynamicParameters();
            parametros.ParametroEntrada(ConstantesUsuario.CodigoUsuario, codigoUsuario);

            return await _connection.QueryAsync<DetallePermiso>(ConstantesUsuario.ProcedimientoConsultarDetallePermisoUsuario,
                param: parametros, commandType: CommandType.StoredProcedure);
        }

        public async Task<(RespuestaGenericaDto respuesta, long id)> ActualizarUsuario(Actualizar actualizar)
        {
            // Configuramos los paramatros de entrada y salida
            var parametros = new DynamicParameters();
            parametros.ParametroEntrada(ConstantesUsuario.Codigo, actualizar.Codigo)
                .ParametroEntrada(ConstantesUsuario.Descripcion, actualizar.Descripcion)
                .ParametroEntradaUsuarioSesion(sesionManager.ObtenerUsuarioSesion())
                .ParametroSalidaLong(ConstantesUsuario.Id)
                .ParametroSalidaRespuestaDto();

            await _connection
                .ExecuteAsync(ConstantesUsuario.ProcedimientoActualizarUsuario, parametros, _transaction, commandType: CommandType.StoredProcedure);

            // Generamos los parametros de salida
            long id = parametros.ParametroSalidaValor<long>(ConstantesUsuario.Id);
            var respuestaDto = parametros.ObtenerRespuestaDto();

            return (respuestaDto, id);
        }

        public async Task<IEnumerable<Usuario>?> ObtenerUsuarios(bool soloActivos)
        {
            var parametros = new DynamicParameters();
            parametros.ParametroEntrada(ConstantesUsuario.SoloActivos, soloActivos);

            return await _connection
                .QueryAsync<Usuario>(ConstantesUsuario.ProcedimientoConsultarUsuarios, parametros, commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<RolPermitido>> ObtenerRolesPermitidosUsuario(long idUsuario)
        {
            var parametros = new DynamicParameters();
            parametros.Add(ConstantesUsuario.IdUsuario, idUsuario);

            return await _connection.QueryAsync<RolPermitido>(ConstantesUsuario.ProcedimientoConsultarRolesPermitidosUsuarios,
                param: parametros, commandType: CommandType.StoredProcedure);
        }

        public async Task<RespuestaGenericaDto> ActualizarRolesUsuario(string codigoUsuario, IEnumerable<RolUsuario> rolesUsuario)
        {
            var parametros = new DynamicParameters();

            parametros.ParametroEntrada(ConstantesUsuario.CodigoUsuario, codigoUsuario)
                .ParametroEntrada(ConstantesUsuario.RolesUsuario, TipoCreadoBaseDatos.RolUsuario, rolesUsuario.ToList())
                .ParametroEntradaUsuarioSesion(sesionManager.ObtenerUsuarioSesion())
                .ParametroSalidaRespuestaDto();

            await _connection
                .ExecuteAsync(ConstantesUsuario.ActualizarRolesUsuario, parametros, _transaction, commandType: CommandType.StoredProcedure);

            return parametros.ObtenerRespuestaDto();
        }

        public async Task<RespuestaGenericaDto> EliminarUsuario(string codigoUsuario)
        {
            // Configuramos los paramatros de entrada y salida
            var parametros = new DynamicParameters();
            parametros.ParametroEntrada(ConstantesUsuario.Codigo, codigoUsuario)
                .ParametroEntradaUsuarioSesion(sesionManager.ObtenerUsuarioSesion())
                .ParametroSalidaRespuestaDto();

            await _connection
                .ExecuteAsync(ConstantesUsuario.ProcedimientoEliminarUsuario, parametros, _transaction, commandType: CommandType.StoredProcedure);

            return parametros.ObtenerRespuestaDto();
        }
    }
}