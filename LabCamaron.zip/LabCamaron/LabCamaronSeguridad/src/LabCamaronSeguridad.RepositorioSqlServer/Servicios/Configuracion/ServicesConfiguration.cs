using LabCamaronSeguridad.Entidad.Interfaz.Configuracion;
using Microsoft.Extensions.DependencyInjection;

namespace LabCamaronSeguridad.RepositorioSqlServer.Servicios.Configuracion
{
    public static class ServicesConfiguration
    {
        public static IServiceCollection AddServiciosConfiguracion(this IServiceCollection services)
        {
            services.AddScoped<IUsuarioRepositorio, UsuarioRepositorio>();
            services.AddScoped<IRolRepositorio, RolRepositorio>();

            return services;
        }
    }
}