using Dapper;
using LabCamaronSeguridad.Entidad.Interfaz.Configuracion;
using LabCamaronSeguridad.Entidad.Modelo.Configuracion;
using LabCamaronSeguridad.Infraestructura.Constantes;
using LabCamaronSeguridad.Infraestructura.Extensiones.Dapper;
using LabCamaronSeguridad.Infraestructura.Modelo;
using LabCamaronSeguridad.Infraestructura.Modelo.Usuario;
using LabCamaronSeguridad.Infraestructura.Services.Sesion;
using LabCamaronSeguridad.RepositorioSqlServer.Constantes.Configuracion;
using System.Data;
using static LabCamaronSeguridad.Entidad.Modelo.Configuracion.Rol;

namespace LabCamaronSeguridad.RepositorioSqlServer.Servicios.Configuracion
{
    internal class RolRepositorio(IDbConnection connection, IDbTransaction transaction, 
        ISesionManager sesionManager) : IRolRepositorio
    {
        private readonly IDbConnection _connection = connection;
        private readonly IDbTransaction _transaction = transaction;
        private readonly ISesionManager sesionManager = sesionManager;

        public async Task<RespuestaGenericaDto> ActualizarPermisosRol(string codigoRol, IEnumerable<PermisoRol.Actualizar> permisos)
        {
            var parametros = new DynamicParameters();
            //var dtPermisos = ConvertirADataTable(listaPermisos);

            parametros.ParametroEntrada(ConstantesRol.CodigoRol, codigoRol)
                .ParametroEntrada(ConstantesRol.ListaPermisos, TipoCreadoBaseDatos.PermisoMenu, permisos.ToList())
                .ParametroEntradaUsuarioSesion(sesionManager.ObtenerUsuarioSesion())
                .ParametroSalidaRespuestaDto();

            await _connection
                .ExecuteAsync(ConstantesRol.ProcedimientoActualizarPermisosRol, parametros, _transaction, commandType: CommandType.StoredProcedure);

            return parametros.ObtenerRespuestaDto();
        }

        public async Task<RespuestaGenericaDto> ActualizarRol(Actualizar actualizar)
        {
            // Configuramos los paramatros de entrada y salida
            var parametros = new DynamicParameters();
            parametros.ParametroEntrada(ConstantesRol.Codigo, actualizar.Codigo)
                .ParametroEntrada(ConstantesRol.Nombre, actualizar.Nombre)
                .ParametroEntrada(ConstantesRol.Descripcion, actualizar.Descripcion ?? string.Empty)
                .ParametroEntradaUsuarioSesion(sesionManager.ObtenerUsuarioSesion())
                .ParametroSalidaRespuestaDto();

            await _connection
                .ExecuteAsync(ConstantesRol.ProcedimientoActualizarRol, parametros, _transaction, commandType: CommandType.StoredProcedure);

            return parametros.ObtenerRespuestaDto();
        }

        public async Task<(RespuestaGenericaDto respuesta, long id)> CrearRol(Crear crear)
        {
            // Configuramos los paramatros de entrada y salida
            var parametros = new DynamicParameters();
            parametros.ParametroEntrada(ConstantesRol.Codigo, crear.Codigo)
                .ParametroEntrada(ConstantesRol.Nombre, crear.Nombre)
                .ParametroEntrada(ConstantesRol.Descripcion, crear.Descripcion ?? string.Empty)
                .ParametroSalidaLong(ConstantesRol.Id)
                .ParametroEntradaUsuarioSesion(sesionManager.ObtenerUsuarioSesion())
                .ParametroSalidaRespuestaDto();

            await _connection
                .ExecuteAsync(ConstantesRol.ProcedimientoCrearRol, parametros, _transaction, commandType: CommandType.StoredProcedure);

            // Generamos los parametros de salida
            long id = parametros.ParametroSalidaValor<long>(ConstantesRol.Id);
            var respuestaDto = parametros.ObtenerRespuestaDto();

            return (respuestaDto, id);
        }

        public async Task<RespuestaGenericaDto> EliminarRol(string codigo)
        {
            // Configuramos los paramatros de entrada y salida
            var parametros = new DynamicParameters();
            parametros.ParametroEntrada(ConstantesRol.Codigo, codigo)
                .ParametroEntradaUsuarioSesion(sesionManager.ObtenerUsuarioSesion())
                .ParametroSalidaRespuestaDto();

            await _connection
                .ExecuteAsync(ConstantesRol.ProcedimientoEliminarRol, parametros, _transaction, commandType: CommandType.StoredProcedure);

            return parametros.ObtenerRespuestaDto();
        }

        public async Task<IEnumerable<PermisoRol>> ObtenerPermisosRol(string codigoRol)
        {
            var parametros = new DynamicParameters();
            parametros.ParametroEntrada(ConstantesRol.CodigoRol, codigoRol);

            return await _connection
                .QueryAsync<PermisoRol>(ConstantesRol.ProcedimientoConsultarPermisosRol, parametros, commandType: CommandType.StoredProcedure);
        }

        public async Task<Rol?> ObtenerRol(string codigo)
        {
            var parametros = new DynamicParameters();
            parametros.ParametroEntrada(ConstantesRol.Codigo, codigo);

            return await _connection
                .QueryFirstOrDefaultAsync<Rol?>(ConstantesRol.ProcedimientoConsultarPorCodigo, parametros, commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<Rol>> ObtenerRoles(bool soloActivos)
        {
            var parametros = new DynamicParameters();
            parametros.ParametroEntrada(ConstantesRol.SoloActivos, soloActivos);

            return await _connection
                .QueryAsync<Rol>(ConstantesRol.ProcedimientoConsultarTodos, parametros, commandType: CommandType.StoredProcedure);
        }
    }
}