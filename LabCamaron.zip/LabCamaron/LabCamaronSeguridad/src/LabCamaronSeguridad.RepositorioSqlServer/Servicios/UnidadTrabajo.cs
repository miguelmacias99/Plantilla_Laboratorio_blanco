using LabCamaronSeguridad.Entidad.Interfaz;
using LabCamaronSeguridad.Entidad.Interfaz.Configuracion;
using LabCamaronSeguridad.Infraestructura.Services.Sesion;
using LabCamaronSeguridad.RepositorioSqlServer.Servicios.Configuracion;
using System.Data;

namespace LabCamaronSeguridad.RepositorioSqlServer.Servicios
{
    internal class UnidadTrabajo(IDbConnection connection, ISesionManager sesionManager) : IUnidadTrabajo
    {
        private readonly IDbConnection _connection = connection;
        private readonly ISesionManager _sesionManager = sesionManager;
        private IDbTransaction _transaction = null!;

        public IUsuarioRepositorio Usuarios => new UsuarioRepositorio(_connection, _transaction, _sesionManager);
        public IRolRepositorio Roles => new RolRepositorio(_connection, _transaction, _sesionManager);

        public void Begin()
        {
            _connection.Open();
            _transaction = _connection.BeginTransaction();
        }

        public void Commit()
        {
            try
            {
                _transaction.Commit();
            }
            catch
            {
                _transaction.Rollback();
                throw;
            }
            finally
            {
                _connection.Close();
            }
        }

        public void Rollback()
        {
            _transaction?.Rollback();
            _connection.Close();
        }
    }
}