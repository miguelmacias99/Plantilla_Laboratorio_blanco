﻿--==============================================================================================================
-- Crear Tablas
--==============================================================================================================

Create table Usuario (
	id bigint identity not null,
	codigo varchar(20) not null,
	descripcion varchar(150) not null,
	tipo char(5) not null,
	activo bit not null,
	usuario_creacion varchar(20) not null,
	fecha_creacion datetime not null,
	usuario_modificacion varchar(20) not null,
	fecha_modificacion datetime not null
)
go

alter table usuario
add constraint pk_usuario primary key(id)
go

alter table usuario
add constraint uq_usuario unique(codigo)
go

create table Usuario_seguridad (
	id bigint identity not null,
	id_usuario bigint not null,
	actualizar_contrasenia bit not null,
	fecha_validez_contrasenia date null,
	hash_contrasenia varchar(500) not null,
	salt_contrasenia varchar(500) not null,
	usuario_creacion varchar(20) not null,
	fecha_creacion datetime not null,
	usuario_modificacion varchar(20) not null,
	fecha_modificacion datetime not null
)
go

alter table usuario_Seguridad 
add constraint pk_usuario_seguridad primary key(id)
go

alter table usuario_Seguridad
add constraint FK_usuario_seguridad foreign key(id_usuario)
references usuario(id)
go

create table modulo(
	id bigint identity not null,
	codigo varchar(10) not null,
	nombre varchar(150) not null,
	descripcion varchar(250) not null,
	orden int not null,
	icono varchar(150) not null,
	activo bit not null,
)
go

alter table modulo
add constraint pk_modulo primary key(id)
go

alter table modulo
add constraint uq_modulo unique(codigo)
go

create table menu
(
	id bigint identity not null,
	id_modulo bigint not null,
	codigo varchar(10) not null,
	nombre varchar(150) not null,
	descripcion varchar(250) not null,
	controlador varchar(250) not null,
	accion varchar(250) not null,
	mostrar bit not null,
	icono varchar(150) not null,
	orden int not null,
	activo bit not null
)
go

alter table menu
add constraint pk_menu primary key(id)
go

alter table menu
add constraint fk_modulo_menu foreign key(id_modulo)
references modulo(id)
go

create table menu_accion
(
	id bigint identity not null,
	id_menu bigint not null,
	orden int not null,
	codigo varchar(10) not null,
	nombre varchar(150) not null,
	descripcion varchar(250) not null,
	activo bit not null
)
go

alter table menu_accion
add constraint pk_menu_accion primary key(id)
go

alter table menu_accion
add constraint fk_menu_accion foreign key(id_menu)
references menu(id)
go

create table rol
(
	id bigint identity not null,
	codigo varchar(10) not null,
	nombre varchar(150) not null,
	descripcion varchar(250) not null,
	activo bit not null,
	usuario_creacion varchar(20) not null,
	fecha_creacion datetime not null,
	usuario_modificacion varchar(20) not null,
	fecha_modificacion datetime not null
)

alter table rol
add constraint pk_rol primary key(id)
go

create table rol_permiso
(
	id bigint identity not null,
	id_rol bigint not null,
	id_menu_accion bigint not null,
	activo bit not null,
	usuario_creacion varchar(20) not null,
	fecha_creacion datetime not null,
	usuario_modificacion varchar(20) not null,
	fecha_modificacion datetime not null
)
go

alter table rol_permiso
add constraint pk_rol_permiso primary key(id)
go

alter table rol_permiso
add constraint uq_rol_permiso unique(id_rol, id_menu_Accion)
go

alter table rol_permiso
add constraint fk_rol_permiso foreign key(id_rol)
references rol(id)
go

alter table rol_permiso
add constraint fk_permiso_menu_accion foreign key(id_menu_accion)
references menu_accion(id)
go

create table usuario_rol
(
	id bigint identity not null,
	id_usuario bigint not null,
	id_rol bigint not null,
	activo bit not null,
	usuario_creacion varchar(20) not null,
	fecha_creacion datetime not null,
	usuario_modificacion varchar(20) not null,
	fecha_modificacion datetime not null
)
go

alter table usuario_rol
add constraint pk_usuario_rol primary key(id)
go

alter table usuario_rol
add constraint uq_usuario_rol unique(id_usuario, id_rol)
go

alter table usuario_rol
add constraint fk_usuario_rol foreign key(id_usuario)
references usuario(id)
go

alter table usuario_rol
add constraint fk_rol_usuario foreign key(id_rol)
references rol(id)
go


--==============================================================================================================
-- Crear tipos
--==============================================================================================================
CREATE TYPE Tp_PermisoMenu AS TABLE (
    idMenuAccion INT,
    tienePermiso BIT
);

CREATE TYPE Tp_RolUsuario AS TABLE (
    idRol INT,
    tienePermiso BIT
);