﻿CREATE OR ALTER PROCEDURE CONSULTAR_ROLES
    @SoloActivos bit
AS
BEGIN
    SET NOCOUNT ON;
	SET QUOTED_IDENTIFIER ON;

    SELECT
		id,
		codigo,
		nombre,
		descripcion,
		activo,
		usuario_creacion usuarioCreacion,
		fecha_creacion fechaCreacion,
		usuario_modificacion usuarioModificacion,
		fecha_modificacion fechaModificacion
	FROM rol
	WHERE (@SoloActivos = 1 AND activo = 1) OR (@SoloActivos = 0)
	ORDER BY 1 DESC;
END
