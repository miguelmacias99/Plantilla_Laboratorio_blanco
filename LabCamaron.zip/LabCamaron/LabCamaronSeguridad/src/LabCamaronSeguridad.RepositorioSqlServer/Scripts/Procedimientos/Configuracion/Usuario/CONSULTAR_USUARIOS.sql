CREATE OR ALTER PROCEDURE CONSULTAR_USUARIOS
    @SoloActivos bit
AS
BEGIN
    SET NOCOUNT ON;
	SET QUOTED_IDENTIFIER ON;

    SELECT
		u.id,
		u.codigo,
		u.descripcion,
		u.tipo,
		u.activo
	FROM Usuario u
	WHERE (@SoloActivos = 1 AND u.activo = 1) OR (@SoloActivos = 0)
	ORDER BY 1 DESC;
END
