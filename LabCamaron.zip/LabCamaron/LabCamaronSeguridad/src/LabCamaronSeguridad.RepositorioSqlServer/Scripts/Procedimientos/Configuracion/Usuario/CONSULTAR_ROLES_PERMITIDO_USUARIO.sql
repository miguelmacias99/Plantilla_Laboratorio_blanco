CREATE OR ALTER PROCEDURE CONSULTAR_ROLES_PERMITIDO_USUARIO
	@IdUsuario BIGINT
AS
BEGIN
    SET NOCOUNT ON;
	SET QUOTED_IDENTIFIER ON;

	SELECT
		r.id,
		r.codigo,
		r.nombre,
		r.descripcion,
		CASE WHEN ur.id_rol IS NULL THEN 0 ELSE 1 END AS tienePermiso
	FROM
		rol r
	LEFT JOIN usuario_rol ur ON r.id = ur.id_rol AND ur.id_usuario = @IdUsuario AND ur.activo = 1
	WHERE
		r.activo = 1;

END