﻿CREATE OR ALTER PROCEDURE CONSULTAR_ROL_USUARIO_ID
	@Id BIGINT
AS
BEGIN
    SET NOCOUNT ON;
	SET QUOTED_IDENTIFIER ON;

	select
		r.id,
		r.codigo,
		r.nombre,
		r.descripcion
	from usuario_rol usr
	inner join rol r on r.id = usr.id_rol
	where usr.id_usuario = @Id
	and r.activo = 1 and usr.activo = 1
END
