﻿CREATE OR ALTER PROCEDURE CONSULTAR_DETALLE_PERMISO_USUARIO
	@CodigoUsuario VARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;
	SET QUOTED_IDENTIFIER ON;

	SELECT
		m.codigo CodigoMenu,
		ma.codigo CodigoPermiso
	FROM usuario_rol ur
	INNER JOIN rol r ON r.id = ur.id_rol 
	INNER JOIN rol_permiso rp ON r.id = rp.id_rol
	INNER JOIN menu_accion ma ON ma.id = rp.id_menu_accion
	INNER JOIN menu m ON m.id = ma.id_menu
	WHERE ur.activo = 1 AND r.activo = 1
	AND rp.activo= 1 AND ma.activo = 1
	AND m.activo = 1 AND id_usuario = (SELECT TOP(1) id FROM Usuario WHERE codigo = @CodigoUsuario)
	
END
