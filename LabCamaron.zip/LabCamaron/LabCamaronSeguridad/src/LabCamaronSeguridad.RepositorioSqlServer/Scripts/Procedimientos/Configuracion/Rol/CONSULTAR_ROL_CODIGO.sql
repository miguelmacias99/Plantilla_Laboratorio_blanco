﻿CREATE OR ALTER PROCEDURE CONSULTAR_ROL_CODIGO
    @codigo varchar(10)
AS
BEGIN
    SET NOCOUNT ON;
	SET QUOTED_IDENTIFIER ON;

    SELECT
		id,
		codigo,
		nombre,
		descripcion,
		activo,
		usuario_creacion usuarioCreacion,
		fecha_creacion fechaCreacion,
		usuario_modificacion usuarioModificacion,
		fecha_modificacion fechaModificacion
	FROM rol 
	WHERE codigo = @codigo;
END

