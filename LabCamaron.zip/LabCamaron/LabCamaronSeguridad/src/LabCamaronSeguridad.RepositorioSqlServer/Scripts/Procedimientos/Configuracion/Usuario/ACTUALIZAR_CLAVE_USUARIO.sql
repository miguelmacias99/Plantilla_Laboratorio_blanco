﻿CREATE or ALTER PROCEDURE ACTUALIZAR_CLAVE_USUARIO
    @Id BIGINT,
    @UsuarioSesion varchar(20),
    @HashContrasenia varchar(500),
    @SaltContrasenia varchar(500),

	@CodigoTransaccion VARCHAR(5) OUTPUT,
	@MensajeTransaccion VARCHAR(250) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
	SET QUOTED_IDENTIFIER ON;
	
	UPDATE Usuario
	SET fecha_modificacion = GETDATE(),
		usuario_modificacion = @UsuarioSesion
	WHERE id = @Id
	
	declare @mesesValidezContrasenia int = 3

	UPDATE Usuario_seguridad
	SET hash_contrasenia = @HashContrasenia,
		salt_contrasenia = @SaltContrasenia,
		fecha_validez_contrasenia = DATEADD(MONTH, @mesesValidezContrasenia, GETDATE()),
		fecha_modificacion = GETDATE(),
		usuario_modificacion = @UsuarioSesion
	WHERE id_usuario = @Id

	SET @CodigoTransaccion = '00000'
	SET @MensajeTransaccion = 'Operacion Existosa'
END
