﻿CREATE OR ALTER PROCEDURE CREAR_ROL
    @codigo varchar(10),
    @nombre varchar(150),
    @descripcion varchar(250),
    @UsuarioSesion varchar(20),

	@Id BIGINT OUTPUT,
	@CodigoTransaccion VARCHAR(5) OUTPUT,
	@MensajeTransaccion VARCHAR(250) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
	SET QUOTED_IDENTIFIER ON;

	IF EXISTS (SELECT 1 FROM rol WHERE codigo = @Codigo)
    BEGIN
		SET @id = 0;
        SET @CodigoTransaccion = '00088';
        SET @MensajeTransaccion = 'Ya existe un rol con el código ingresado';
        RETURN;
    END

    INSERT INTO rol (codigo, nombre, descripcion, activo, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
    VALUES (@codigo, @nombre, @descripcion, 1, @UsuarioSesion, GETDATE(), @UsuarioSesion, GETDATE());
	
    -- Obtenemos el ID del usuario recién insertado
    set @id = SCOPE_IDENTITY();
	SET @CodigoTransaccion = '00000'
	SET @MensajeTransaccion = 'Operacion Existosa'
END
