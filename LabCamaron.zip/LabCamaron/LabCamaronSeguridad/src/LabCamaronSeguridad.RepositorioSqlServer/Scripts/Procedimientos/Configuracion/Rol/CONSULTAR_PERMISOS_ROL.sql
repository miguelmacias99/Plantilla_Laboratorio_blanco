CREATE OR ALTER PROCEDURE CONSULTAR_PERMISOS_ROL
	@CodigoRol varchar(10)
AS
BEGIN
    SET NOCOUNT ON;
	SET QUOTED_IDENTIFIER ON;
	
	declare @permisos table (
		ordenModulo int,
		nombreModulo varchar(150),
		ordenMenu int,
		codigoMenu varchar(10),
		nombreMenu varchar(150),
		idMenuAccion bigint,
		ordenAccion int,
		codigoAccion varchar(10),
		nombreAccion varchar(150),
		descripcionAccion varchar(200),
		tienePermiso bit
	)

	insert into @permisos(ordenModulo,nombreModulo,ordenMenu,codigoMenu,nombreMenu,idMenuAccion,ordenAccion,codigoAccion,nombreAccion,descripcionAccion,tienePermiso)
	SELECT
		mo.orden ordenModulo,
		mo.nombre nombreModulo,
		m.orden ordenMenu,
		m.codigo codigoMenu,
		m.nombre nombreMenu,
		ma.id idMenuAccion,
		ma.orden ordenAccion,
		ma.codigo codigoAccion,
		ma.nombre nombreAccion,
		ma.descripcion descripcionAccion,
		0
	FROM Menu m
	inner join modulo mo on mo.id = m.id_modulo
	INNER JOIN menu_accion ma on m.id = ma.id_menu
	order by mo.orden, mo.nombre, m.orden, m.nombre, ma.orden

	update @permisos
	set tienePermiso = 1
	where idMenuAccion in (
		select id_menu_accion from rol_permiso where id_rol = (
			select top(1) id from rol where codigo = @codigoRol
		) and activo = 1
	)

	select 
		ordenModulo,
		nombreModulo,
		ordenMenu,
		codigoMenu,
		nombreMenu,
		idMenuAccion,
		ordenAccion,
		codigoAccion,
		nombreAccion,
		descripcionAccion,
		tienePermiso
	from @permisos
END

