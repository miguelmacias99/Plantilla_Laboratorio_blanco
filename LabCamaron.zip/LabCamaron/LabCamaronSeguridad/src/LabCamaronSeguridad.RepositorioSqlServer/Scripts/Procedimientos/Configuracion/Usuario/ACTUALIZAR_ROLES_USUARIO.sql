CREATE OR ALTER PROCEDURE ACTUALIZAR_ROLES_USUARIO
    @CodigoUsuario varchar(10),
    @RolesUsuario Tp_RolUsuario READONLY,
	
    @UsuarioSesion varchar(20),
	@CodigoTransaccion VARCHAR(5) OUTPUT,
	@MensajeTransaccion VARCHAR(250) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
	SET QUOTED_IDENTIFIER ON;

    -- Obtener el ID del rol con base en el c�digo proporcionado
    DECLARE @idUsuario bigint;
    SELECT @idUsuario = id
    FROM Usuario
    WHERE codigo = @CodigoUsuario;	

    -- Si no existe el rol, devolver un error
    IF @idUsuario IS NULL
    BEGIN
        SET @CodigoTransaccion = '00088';
        SET @MensajeTransaccion = 'El usuario indicado no existe';
        RETURN;
    END
	
    -- Actualizar o insertar permisos
    MERGE INTO usuario_rol AS target
    USING @RolesUsuario AS source
        ON target.id_usuario = @idUsuario AND target.id_rol = source.idRol
    WHEN MATCHED THEN
        UPDATE SET 
            activo = source.tienePermiso,
            usuario_modificacion = @UsuarioSesion,
            fecha_modificacion = GETDATE()
    WHEN NOT MATCHED THEN
        INSERT (id_rol, id_usuario, activo, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
        VALUES (source.idRol, @idUsuario, source.tienePermiso, @UsuarioSesion, GETDATE(), @UsuarioSesion, GETDATE());

	SET @CodigoTransaccion = '00000'
	SET @MensajeTransaccion = 'Operacion Existosa'
END;
