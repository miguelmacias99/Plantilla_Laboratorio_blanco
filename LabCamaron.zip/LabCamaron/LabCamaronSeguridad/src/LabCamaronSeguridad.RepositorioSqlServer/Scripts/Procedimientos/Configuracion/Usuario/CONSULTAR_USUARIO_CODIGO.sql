﻿CREATE OR ALTER PROCEDURE CONSULTAR_USUARIO_CODIGO
	@Codigo VARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;
	SET QUOTED_IDENTIFIER ON;

	SELECT 
		u.id,
		u.codigo,
		u.descripcion,
		u.tipo,
		u.activo,
		us.actualizar_contrasenia actualizarContrasenia,
		us.fecha_validez_contrasenia fechaValidezContrasenia,
		us.hash_contrasenia hashContrasenia,
		us.salt_contrasenia saltContrasenia
	FROM Usuario U
	INNER JOIN Usuario_seguridad US
	ON U.id = US.id_usuario
	WHERE U.codigo = @Codigo
END
