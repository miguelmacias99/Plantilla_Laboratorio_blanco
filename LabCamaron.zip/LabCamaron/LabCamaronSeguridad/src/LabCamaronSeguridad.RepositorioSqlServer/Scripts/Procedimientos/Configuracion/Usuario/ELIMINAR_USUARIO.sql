CREATE or ALTER PROCEDURE ELIMINAR_USUARIO
    @Codigo varchar(20),
    @UsuarioSesion varchar(20),

	@CodigoTransaccion VARCHAR(5) OUTPUT,
	@MensajeTransaccion VARCHAR(250) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
	SET QUOTED_IDENTIFIER ON;

	IF NOT EXISTS (SELECT 1 FROM Usuario WHERE codigo = @Codigo)
    BEGIN
        SET @CodigoTransaccion = '00088';
        SET @MensajeTransaccion = 'No existe un usuario con el c�digo ingresado';
        RETURN;
    END

    --	Actualizamos el registro en la tabla Usuario
	Update Usuario
	set activo = 0,
		usuario_modificacion = @UsuarioSesion,
		fecha_modificacion = GETDATE()
	WHERE codigo = @Codigo;

	SET @CodigoTransaccion = '00000'
	SET @MensajeTransaccion = 'Operacion Existosa'
END
