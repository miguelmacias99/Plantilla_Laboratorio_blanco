﻿CREATE or ALTER PROCEDURE ACTUALIZAR_ROL
    @codigo varchar(10),
    @nombre varchar(150),
    @descripcion varchar(250),
    @UsuarioSesion varchar(20),

	@CodigoTransaccion VARCHAR(5) OUTPUT,
	@MensajeTransaccion VARCHAR(250) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
	SET QUOTED_IDENTIFIER ON;

    UPDATE rol
    SET nombre = @nombre,
        descripcion = @descripcion,
        usuario_modificacion = @UsuarioSesion,
        fecha_modificacion = GETDATE()
    WHERE codigo = @codigo;

	SET @CodigoTransaccion = '00000'
	SET @MensajeTransaccion = 'Operacion Existosa'
END
