﻿CREATE or ALTER PROCEDURE CREAR_USUARIO
    @Codigo varchar(20),
    @Descripcion varchar(150),
    @Tipo char(5),
    @UsuarioSesion varchar(20),
    @ActualizarContrasenia bit,
    @HashContrasenia varchar(500),
    @SaltContrasenia varchar(500),

	@CodigoTransaccion VARCHAR(5) OUTPUT,
	@MensajeTransaccion VARCHAR(250) OUTPUT,
    @id BIGINT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
	SET QUOTED_IDENTIFIER ON;

	IF EXISTS (SELECT 1 FROM Usuario WHERE codigo = @Codigo)
    BEGIN
		SET @id = 0;
        SET @CodigoTransaccion = '00088';
        SET @MensajeTransaccion = 'Ya existe un usuario con el código ingresado';
        RETURN;
    END

    -- Insertamos en la tabla Usuario
    INSERT INTO Usuario (
        codigo,
        descripcion,
        tipo,
        activo,
        usuario_creacion,
        fecha_creacion,
		usuario_modificacion,
		fecha_modificacion
    )
    VALUES (
        @codigo,
        @descripcion,
        @tipo,
        1,
        @UsuarioSesion,
        GETDATE(),
        @UsuarioSesion,
        GETDATE()
    );

    -- Obtenemos el ID del usuario recinin insertado
    set @id = SCOPE_IDENTITY();
	
	declare @mesesValidezContrasenia int = 3

    -- Insertamos en la tabla Usuario_seguridad
    INSERT INTO Usuario_seguridad (
        id_usuario,
        actualizar_contrasenia,
        fecha_validez_contrasenia,
        hash_contrasenia,
        salt_contrasenia,
        usuario_creacion,
        fecha_creacion,
		usuario_modificacion,
		fecha_modificacion
    )
    VALUES (
        @id,
        @ActualizarContrasenia,
        DATEADD(MONTH, @mesesValidezContrasenia, GETDATE()),
        @HashContrasenia,
        @SaltContrasenia,
        @UsuarioSesion,
        GETDATE(),
        @UsuarioSesion,
        GETDATE()
    );

	SET @CodigoTransaccion = '00000'
	SET @MensajeTransaccion = 'Operacion Existosa'
END
