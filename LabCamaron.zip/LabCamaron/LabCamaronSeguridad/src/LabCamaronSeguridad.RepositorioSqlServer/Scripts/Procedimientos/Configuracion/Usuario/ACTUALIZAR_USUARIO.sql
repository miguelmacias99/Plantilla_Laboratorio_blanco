﻿CREATE or ALTER PROCEDURE ACTUALIZAR_USUARIO
    @Codigo varchar(20),
    @Descripcion varchar(150),

    @UsuarioSesion varchar(20),
	@CodigoTransaccion VARCHAR(5) OUTPUT,
	@MensajeTransaccion VARCHAR(250) OUTPUT,
    @id BIGINT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
	SET QUOTED_IDENTIFIER ON;

	IF NOT EXISTS (SELECT 1 FROM Usuario WHERE codigo = @Codigo)
    BEGIN
		SET @id = 0;
        SET @CodigoTransaccion = '00088';
        SET @MensajeTransaccion = 'No existe un usuario con el código ingresado';
        RETURN;
    END

    -- Actualizamos el usuario
    UPDATE Usuario
    SET
        descripcion = @Descripcion,
        usuario_modificacion = @UsuarioSesion,
        fecha_modificacion = GETDATE()
    WHERE
        codigo = @Codigo;

	SET @id = (SELECT TOP(1) id FROM Usuario WHERE codigo = @Codigo)
	SET @CodigoTransaccion = '00000'
	SET @MensajeTransaccion = 'Operacion Existosa'
END
