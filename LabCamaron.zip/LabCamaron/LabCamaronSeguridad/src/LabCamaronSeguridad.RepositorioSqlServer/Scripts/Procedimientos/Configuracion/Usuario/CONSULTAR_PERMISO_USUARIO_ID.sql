﻿CREATE OR ALTER PROCEDURE CONSULTAR_PERMISO_USUARIO_ID
	@Id BIGINT
AS
BEGIN
    SET NOCOUNT ON;
	SET QUOTED_IDENTIFIER ON;

	select
		mo.id, mo.orden, mo.codigo, mo.nombre, mo.descripcion, mo.icono iconoModulo,
		m.id, m.orden, m.codigo, m.nombre, m.descripcion, m.controlador, m.accion, m.mostrar, m.icono iconoMenu,
		ma.id, ma.codigo, ma.nombre, ma.descripcion
	from usuario_rol usr
	inner join Usuario u on u.id = usr.id_usuario
	inner join rol_permiso rp on rp.id_rol = usr.id_rol
	inner join menu_accion ma on ma.id = rp.id_menu_accion
	inner join menu m on m.id = ma.id_menu
	inner join modulo mo on mo.id = m.id_modulo
	where u.id = @Id
	and usr.activo = 1 and ma.activo = 1
	and u.activo = 1 and rp.activo = 1
	and m.activo = 1 and mo.activo = 1
END
