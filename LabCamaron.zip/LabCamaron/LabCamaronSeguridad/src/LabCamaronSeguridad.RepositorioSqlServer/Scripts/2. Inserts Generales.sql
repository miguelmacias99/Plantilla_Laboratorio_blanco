﻿--==============================================================================================================
-- Insert de usuario admin psw: admin
--==============================================================================================================

insert into Usuario(codigo,descripcion,tipo,activo,usuario_creacion,fecha_creacion,usuario_modificacion,fecha_modificacion)
select 'admin','Usuario administrador','ADMIN',1,'mamz9524',GETDATE(),'mamz9524',GETDATE()

insert into Usuario_seguridad(id_usuario,actualizar_contrasenia,hash_contrasenia,salt_contrasenia,usuario_creacion,fecha_creacion,usuario_modificacion,fecha_modificacion,fecha_validez_contrasenia)
select (select top(1) id from Usuario where codigo = 'admin'),0,'pRInwpUlBU/CqLbq4SYPf4weHBVFDV0K7tFTR3I8Qhs=','7L7XwU3/Qh+FpQ10UDiPXg==','mamz9524',GETDATE(),'mamz9524',GETDATE(),null

--==============================================================================================================
-- Insert de modulos
--==============================================================================================================
INSERT INTO modulo(codigo,nombre,descripcion,activo,orden,icono)
select 'CONFIGURAC', 'Configuración', 'Opciones de configuración', 1, 1,'bx bx-wrench'


--==============================================================================================================
-- Insert de menus
--==============================================================================================================
INSERT INTO menu(id_modulo,codigo,nombre,descripcion,activo,controlador,accion,orden,mostrar,icono)
select (select top(1) id from modulo where codigo = 'CONFIGURAC'), 'GENERAL', 'Menú general', 'Menu general', 1, '', '', 1, 0,'' union
select (select top(1) id from modulo where codigo = 'CONFIGURAC'), 'ROL', 'Gestión de Roles', 'Menu de Rol', 1, 'Rol', 'Index', 1, 1,'bx bx-pin' union
select (select top(1) id from modulo where codigo = 'CONFIGURAC'), 'USUARIO', 'Gestión de Usuarios', 'Menu de Usuarios', 1, 'Usuario', 'Index', 1, 1,'bx bx-user'


--==============================================================================================================
-- Insert de acciones de menu
--==============================================================================================================
INSERT INTO menu_accion(id_menu,codigo,nombre,descripcion,activo,orden)
select (select top(1) id from menu where codigo = 'GENERAL'),'VER','VER','Permite visualizar la opción',1,1 union
select (select top(1) id from menu where codigo = 'GENERAL'),'USCAMCLAVE','CAMBIAR CLAVE','Permite actualizar la clave al usuario',1,2 union
select (select top(1) id from menu where codigo = 'GENERAL'),'USACTDATOS','ACTUALIZAR DATOS','Permite actualizar datos al usuario',1,3

INSERT INTO menu_accion(id_menu,codigo,nombre,descripcion,activo, orden)
select (select top(1) id from menu where codigo = 'ROL'),'EDIPERMISO','EDITAR PERMISOS','Permite editar los permisos de un rol',1,5 union
select (select top(1) id from menu where codigo = 'ROL'),'ELIMINAR','ELIMINAR','Permite eliminar un registro',1,4 union
select (select top(1) id from menu where codigo = 'ROL'),'EDITAR','EDITAR','Permite editar un registro',1,3 union
select (select top(1) id from menu where codigo = 'ROL'),'CREAR','CREAR','Permite crear un registro',1,2 union
select (select top(1) id from menu where codigo = 'ROL'),'VER','VER','Permite visualizar la opción',1,1

INSERT INTO menu_accion(id_menu,codigo,nombre,descripcion,activo, orden)
select (select top(1) id from menu where codigo = 'USUARIO'),'ELIMINAR','ELIMINAR','Permite eliminar un registro',1,6 union
select (select top(1) id from menu where codigo = 'USUARIO'),'EDITROLES','EDITAR ROLES','Permite editar los roles de un usuario',1,5 union
select (select top(1) id from menu where codigo = 'USUARIO'),'RESTACLAVE','RESTABLECER CONTRASEÑA','Permite restablecer contraseña de un usuario',1,4 union
select (select top(1) id from menu where codigo = 'USUARIO'),'EDITAR','EDITAR','Permite editar un registro',1,3 union
select (select top(1) id from menu where codigo = 'USUARIO'),'CREAR','CREAR','Permite crear un registro',1,2 union
select (select top(1) id from menu where codigo = 'USUARIO'),'VER','VER','Permite visualizar la opción',1,1


--==============================================================================================================
-- Insert de roles
--==============================================================================================================
insert into Rol (codigo, nombre, descripcion, activo, usuario_creacion,fecha_creacion,usuario_modificacion,fecha_modificacion)
select 'ADMIN','Rol de Administrador','Rol de Administrador',1,'mamz9524',GETDATE(),'mamz9524',GETDATE()

--==============================================================================================================
-- Insert de permisos del rol
--==============================================================================================================
MERGE INTO rol_permiso AS target
USING (
    SELECT 
        (SELECT TOP(1) id FROM Rol WHERE codigo = 'ADMIN') AS id_rol,
        id AS id_menu_accion,
        1 AS activo,
        'mamz9524' AS usuario_creacion,
        GETDATE() AS fecha_creacion,
        'mamz9524' AS usuario_modificacion,
        GETDATE() AS fecha_modificacion
    FROM menu_accion
    WHERE activo = 1
) AS source
ON target.id_rol = source.id_rol AND target.id_menu_accion = source.id_menu_accion
WHEN NOT MATCHED THEN
    INSERT (id_rol, id_menu_accion, activo, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
    VALUES (source.id_rol, source.id_menu_accion, source.activo, source.usuario_creacion, source.fecha_creacion, source.usuario_modificacion, source.fecha_modificacion);


--==============================================================================================================
-- Insert de personas - roles
--==============================================================================================================
insert into usuario_rol (id_usuario,id_rol,activo,usuario_creacion,fecha_creacion,usuario_modificacion,fecha_modificacion)
select (SELECT TOP(1) id From usuario where codigo = 'admin'), (SELECT TOP(1) id From Rol where codigo = 'ADMIN'),1,'mamz9524',GETDATE(),'mamz9524',GETDATE()