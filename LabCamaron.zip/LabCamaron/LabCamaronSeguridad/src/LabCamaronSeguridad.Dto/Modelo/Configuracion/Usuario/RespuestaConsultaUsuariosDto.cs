﻿using LabCamaronSeguridad.Infraestructura.Modelo;

namespace LabCamaronSeguridad.Dto.Modelo.Configuracion.Usuario
{
    public class RespuestaConsultaUsuariosDto
    {
        public RespuestaGenericaDto Respuesta { get; set; } = null!;
        public List<UsuarioDto>? Usuarios { get; set; }
        public RespuestaConsultaUsuariosDto()
        {

        }
        public RespuestaConsultaUsuariosDto(RespuestaGenericaDto respuesta)
        {
            Respuesta = respuesta;
        }
    }
}
