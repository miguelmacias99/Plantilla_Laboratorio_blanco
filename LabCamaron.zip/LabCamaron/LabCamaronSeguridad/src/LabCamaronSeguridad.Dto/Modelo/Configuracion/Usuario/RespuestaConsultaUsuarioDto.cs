﻿using LabCamaronSeguridad.Infraestructura.Modelo;

namespace LabCamaronSeguridad.Dto.Modelo.Configuracion.Usuario
{
    public class RespuestaConsultaUsuarioDto
    {
        public RespuestaGenericaDto Respuesta { get; set; } = null!;
        public UsuarioDto? Usuario { get; set; }

        public RespuestaConsultaUsuarioDto()
        {

        }
        public RespuestaConsultaUsuarioDto(RespuestaGenericaDto respuesta)
        {
            Respuesta = respuesta;
        }
    }
}
