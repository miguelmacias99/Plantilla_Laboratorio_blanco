using LabCamaronSeguridad.Infraestructura.Modelo;
using LabCamaronSeguridad.Infraestructura.Modelo.Token;

namespace LabCamaronSeguridad.Dto.Modelo.Configuracion.Login
{
    public class RespuestaLoginDto
    {
        public RespuestaGenericaDto Respuesta { get; set; } = null!;
        public string IdentificadorSesion { get; set; } = string.Empty;
        public PermisoUsuarioDto Permisos { get; set; } = null!;
        public JwtModel Jwt { get; set; } = null!;

        public RespuestaLoginDto()
        {
        }

        public RespuestaLoginDto(RespuestaGenericaDto respuesta)
        {
            Respuesta = respuesta;
        }
    }
}