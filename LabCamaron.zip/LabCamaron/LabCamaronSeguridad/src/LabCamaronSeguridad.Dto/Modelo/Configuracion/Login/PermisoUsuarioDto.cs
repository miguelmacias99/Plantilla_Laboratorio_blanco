namespace LabCamaronSeguridad.Dto.Modelo.Configuracion.Login
{
    public class PermisoUsuarioDto
    {
        public UsuarioDto Usuario { get; set; } = new UsuarioDto();
        public List<ModuloDto> Modulos { get; set; } = [];
        public List<RolDto> Roles { get; set; } = [];

        public class UsuarioDto
        {
            public long Id { get; set; }
            public string Codigo { get; set; } = string.Empty;
            public string Descripcion { get; set; } = string.Empty;
            public DateTime? FechaValidezContrasenia { get; set; }
            public bool RequiereNuevaContraseña => ((FechaValidezContrasenia is null) || (DateTime.Now > FechaValidezContrasenia));
        }

        public class ModuloDto
        {
            public long Id { get; set; }
            public int Orden { get; set; }
            public string Codigo { get; set; } = string.Empty;
            public string Nombre { get; set; } = string.Empty;
            public string IconoModulo { get; set; } = string.Empty;
            public List<MenuDto> Menus { get; set; } = [];
        }

        public class MenuDto
        {
            public long Id { get; set; }
            public int Orden { get; set; }
            public string Codigo { get; set; } = string.Empty;
            public string Nombre { get; set; } = string.Empty;
            public string Controlador { get; set; } = string.Empty;
            public string Accion { get; set; } = string.Empty;
            public string IconoMenu { get; set; } = string.Empty;
            public bool Mostrar { get; set; }
            public List<PermisoDto> Permisos { get; set; } = [];
        }

        public class PermisoDto
        {
            public long Id { get; set; }
            public string Codigo { get; set; } = string.Empty;
            public string Nombre { get; set; } = string.Empty;
        }

        public class RolDto
        {
            public long Id { get; set; }
            public string Codigo { get; set; } = string.Empty;
            public string Nombre { get; set; } = string.Empty;
            public string Descripcion { get; set; } = string.Empty;
        }
    }
}