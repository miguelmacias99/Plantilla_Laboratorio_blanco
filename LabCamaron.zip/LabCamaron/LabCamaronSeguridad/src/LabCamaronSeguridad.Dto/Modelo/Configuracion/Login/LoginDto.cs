using System.ComponentModel.DataAnnotations;

namespace LabCamaronSeguridad.Dto.Modelo.Configuracion.Login
{
    public class LoginDto
    {
        [Required(ErrorMessage = "Usuario es obligatorio")]
        public string? Usuario { get; set; }

        [Required(ErrorMessage = "Contraseña es obligatorio")]
        public string? Contrasenia { get; set; }
    }
}