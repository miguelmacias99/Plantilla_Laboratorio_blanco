﻿using LabCamaronSeguridad.Infraestructura.Modelo;

namespace LabCamaronSeguridad.Dto.Modelo.Configuracion.Login
{
    public class RespuestaPermisosDto
    {
        public RespuestaGenericaDto Respuesta { get; set; } = null!;
        public PermisoUsuarioDto? PermisoUsuario { get; set; }
        public RespuestaPermisosDto()
        {
        }

        public RespuestaPermisosDto(RespuestaGenericaDto respuesta)
        {
            Respuesta = respuesta;
        }
    }
}
