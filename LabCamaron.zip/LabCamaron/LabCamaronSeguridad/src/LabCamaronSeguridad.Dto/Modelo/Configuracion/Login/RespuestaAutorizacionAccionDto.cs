using LabCamaronSeguridad.Infraestructura.Modelo;

namespace LabCamaronSeguridad.Dto.Modelo.Configuracion.Login
{
    public class RespuestaAutorizacionAccionDto
    {
        public RespuestaGenericaDto Respuesta { get; set; } = null!;
        public bool TieneAutorizacion { get; set; }

        public RespuestaAutorizacionAccionDto() { }
        public RespuestaAutorizacionAccionDto(RespuestaGenericaDto respuesta) 
        { 
            Respuesta = respuesta;
        }
    }
}
