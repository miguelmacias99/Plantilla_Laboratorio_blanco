﻿using LabCamaronSeguridad.Infraestructura.Modelo;

namespace LabCamaronSeguridad.Dto.Modelo.Configuracion.Rol
{
    public class RespuestaConsultaPermisosRolDto
    {
        public RespuestaGenericaDto Respuesta { get; set; } = null!;
        public PermisoRolDto? Permisos { get; set; }

        public RespuestaConsultaPermisosRolDto()
        {
        }

        public RespuestaConsultaPermisosRolDto(RespuestaGenericaDto respuesta)
        {
            Respuesta = respuesta;
        }
    }
}
