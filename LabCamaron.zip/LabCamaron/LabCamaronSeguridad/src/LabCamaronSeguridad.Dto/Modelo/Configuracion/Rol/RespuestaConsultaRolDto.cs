using LabCamaronSeguridad.Infraestructura.Modelo;

namespace LabCamaronSeguridad.Dto.Modelo.Configuracion.Rol
{
    public class RespuestaConsultaRolDto
    {
        public RespuestaGenericaDto Respuesta { get; set; } = null!;
        public RolDto? Rol { get; set; }

        public RespuestaConsultaRolDto()
        {
        }

        public RespuestaConsultaRolDto(RespuestaGenericaDto respuesta)
        {
            Respuesta = respuesta;
        }
    }
}