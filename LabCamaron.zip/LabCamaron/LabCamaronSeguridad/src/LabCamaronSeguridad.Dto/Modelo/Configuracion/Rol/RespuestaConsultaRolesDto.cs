using LabCamaronSeguridad.Infraestructura.Modelo;

namespace LabCamaronSeguridad.Dto.Modelo.Configuracion.Rol
{
    public class RespuestaConsultaRolesDto
    {
        public RespuestaGenericaDto Respuesta { get; set; } = null!;
        public List<RolDto>? Roles { get; set; }

        public RespuestaConsultaRolesDto()
        {
        }

        public RespuestaConsultaRolesDto(RespuestaGenericaDto respuesta)
        {
            Respuesta = respuesta;
        }
    }
}