using LabCamaronSeguridad.Infraestructura.Constantes;
using LabCamaronSeguridad.Infraestructura.Modelo.Usuario;
using LabCamaronSeguridad.Infraestructura.Services.Token;
using Microsoft.AspNetCore.Http;

namespace LabCamaronSeguridad.Infraestructura.Services.Sesion
{
    internal class SesionManager(IHttpContextAccessor contextAccessor, IJwtService jwtService) : ISesionManager
    {
        private readonly IHttpContextAccessor _contextAccessor = contextAccessor;
        private readonly IJwtService _jwtService = jwtService;

        public UsuarioSesion ObtenerUsuarioSesion()
        {
            var token = _contextAccessor.HttpContext.Request.Headers[ConstantesSesion.Authorization];
            var usuarioSesion = _jwtService.GetClaimJwtToken(token, ConstantesSesion.CodigoUsuario);
            var descripcionUsuario = _jwtService.GetClaimJwtToken(token, ConstantesSesion.CodigoUsuario);

            return new UsuarioSesion() {
                Codigo = usuarioSesion,
                Descripcion = descripcionUsuario
            };
        }
    }
}
