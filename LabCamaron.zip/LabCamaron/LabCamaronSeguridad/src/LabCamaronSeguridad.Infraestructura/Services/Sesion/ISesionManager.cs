using LabCamaronSeguridad.Infraestructura.Modelo.Usuario;

namespace LabCamaronSeguridad.Infraestructura.Services.Sesion
{
    public interface ISesionManager
    {
        UsuarioSesion ObtenerUsuarioSesion();
    }
}
