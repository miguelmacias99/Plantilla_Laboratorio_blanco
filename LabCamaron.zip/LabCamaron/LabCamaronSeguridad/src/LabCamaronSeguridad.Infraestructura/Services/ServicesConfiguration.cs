using LabCamaronSeguridad.Infraestructura.Services.Encriptacion;
using LabCamaronSeguridad.Infraestructura.Services.Redis;
using LabCamaronSeguridad.Infraestructura.Services.Sesion;
using LabCamaronSeguridad.Infraestructura.Services.Token;
using Microsoft.Extensions.DependencyInjection;

namespace LabCamaronSeguridad.Infraestructura.Services
{
    public static class ServicesConfiguration
    {
        public static IServiceCollection ConfigurarInfraestructura(this IServiceCollection services)
        {
            services.AddScoped<IJwtService, JwtService>();
            services.AddScoped<IRedisCacheService, RedisCacheService>();
            services.AddScoped<ISesionManager, SesionManager>();
            services.AddScoped<IEncriptarTextoService, EncriptarTextoService>();

            return services;
        }
    }
}