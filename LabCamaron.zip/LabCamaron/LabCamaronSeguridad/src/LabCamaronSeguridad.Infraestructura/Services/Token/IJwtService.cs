using LabCamaronSeguridad.Infraestructura.Modelo.Token;
using LabCamaronSeguridad.Infraestructura.Modelo.Usuario;
using System.Runtime.CompilerServices;

namespace LabCamaronSeguridad.Infraestructura.Services.Token
{
    public interface IJwtService
    {
        JwtModel GenerateJwtToken(UsuarioSesion usuario, [CallerMemberName] string metodoInvoca = "");
        string GetClaimJwtToken(string? token, string claimName, [CallerMemberName] string metodoInvoca = "");
    }
}