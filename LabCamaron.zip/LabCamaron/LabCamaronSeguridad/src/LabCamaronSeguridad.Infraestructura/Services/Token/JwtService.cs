using LabCamaronSeguridad.Infraestructura.Constantes;
using LabCamaronSeguridad.Infraestructura.Modelo.Token;
using LabCamaronSeguridad.Infraestructura.Modelo.Usuario;
using LabCamaronSeguridad.Infraestructura.Utilidades.Logger;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Runtime.CompilerServices;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace LabCamaronSeguridad.Infraestructura.Services.Token
{
    public class JwtService(IConfiguration configuration) : IJwtService
    {
        private readonly IConfiguration configuration = configuration;

        public JwtModel GenerateJwtToken(UsuarioSesion usuario, [CallerMemberName] string metodoInvoca = "")
        {
            try
            {
                var authClaims = new List<Claim>
                {
                    new(ConstantesSesion.CodigoUsuario, usuario.Codigo),
                    new(ConstantesSesion.DescripcionUsuario, usuario.Descripcion),
                    new(ConstantesSesion.Identificador, Guid.NewGuid().ToString()),
                };

                var audiencias = configuration["JWT:ValidAudience"]!.Split(",");
                foreach (var audiencia in audiencias)
                {
                    authClaims.Add(new(JwtRegisteredClaimNames.Aud, audiencia));
                }

                var token = CreateToken(authClaims);
                var refreshToken = GenerateRefreshToken();

                var jwtToken = new JwtSecurityTokenHandler().WriteToken(token);

                return new(jwtToken, refreshToken);
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, metodoInvoca: metodoInvoca);
                throw;
            }
        }

        public string GetClaimJwtToken(string? token, string claimName, [CallerMemberName] string metodoInvoca = "")
        {
            try
            {
                ArgumentException.ThrowIfNullOrEmpty(token);

                var clearToken = token.Replace(ConstantesSesion.Bearer, string.Empty);
                var tokenHandler = new JwtSecurityTokenHandler();
                var securityToken = (JwtSecurityToken)tokenHandler.ReadToken(clearToken);
                var claimValue = securityToken.Claims.FirstOrDefault(c => c.Type == claimName)?.Value 
                    ?? throw new KeyNotFoundException("No se ha encontrado la información solicitada en el token");
                return claimValue;
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, metodoInvoca: metodoInvoca);
                throw;
            }
        }

        private JwtSecurityToken CreateToken(List<Claim> authClaims)
        {
            var authSigningKey = new SymmetricSecurityKey(GetSecretFromServices());
            _ = int.TryParse(configuration["JWT:TokenValidityInMinutes"], out int tokenValidityInMinutes);

            var token = new JwtSecurityToken(
                issuer: configuration["JWT:ValidIssuer"],
                expires: DateTime.Now.AddMinutes(tokenValidityInMinutes),
                claims: authClaims,
                signingCredentials: new SigningCredentials(authSigningKey, SecurityAlgorithms.HmacSha256)
            );

            return token;
        }

        private byte[] GetSecretFromServices()
        {
            return Encoding.UTF8.GetBytes(configuration["JWT:Secret"]!);
        }

        private static string GenerateRefreshToken()
        {
            var randomNumber = new byte[64];
            using var rng = RandomNumberGenerator.Create();
            rng.GetBytes(randomNumber);
            return Convert.ToBase64String(randomNumber);
        }


        private ClaimsPrincipal? GetPrincipalFromExpiredToken(string? token)
        {
            var tokenValidationParameters = new TokenValidationParameters
            {
                ValidateAudience = false,
                ValidateIssuer = false,
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(GetSecretFromServices()),
                ValidateLifetime = false
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var principal = tokenHandler.ValidateToken(token, tokenValidationParameters, out SecurityToken securityToken);
            if (securityToken is not JwtSecurityToken jwtSecurityToken || !jwtSecurityToken.Header.Alg.Equals(SecurityAlgorithms.HmacSha256, StringComparison.InvariantCultureIgnoreCase))
                throw new SecurityTokenException("Invalid token");

            return principal;
        }
    }
}