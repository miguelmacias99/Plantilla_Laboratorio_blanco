namespace LabCamaronSeguridad.Infraestructura.Constantes
{
    public static class ConstantesRedis
    {
        public static readonly string PrefijoUsuario = "Usuario_";
        public static readonly string PrefijoDetallesPermisos = "DetallesPermisos_";
        public static readonly string PrefijoPermisos = "Permisos_";
    }
}