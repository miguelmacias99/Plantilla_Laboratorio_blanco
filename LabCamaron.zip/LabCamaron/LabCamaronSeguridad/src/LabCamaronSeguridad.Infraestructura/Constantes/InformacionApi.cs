namespace LabCamaronSeguridad.Infraestructura.Constantes
{
    public static class InformacionApi
    {
        public static string Nombre { get; set; } = null!;
        public static readonly string IdentificadoApi = "ED9A3CE2-9756-4654-9E23-FFEAAD52B5B6";
    }
}