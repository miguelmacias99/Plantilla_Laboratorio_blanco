﻿namespace LabCamaronSeguridad.Infraestructura.Constantes
{
    public class TipoCreadoBaseDatos
    {
        public const string PermisoMenu = "Tp_PermisoMenu";
        public const string RolUsuario = "Tp_RolUsuario";
    }
}
