namespace LabCamaronSeguridad.Infraestructura.Constantes
{
    public static class ConstantesSesion
    {
        public readonly static string Bearer = "Bearer ";
        public readonly static string Authorization = "Authorization";
        public readonly static string Identificador = "IDENTIFICADOR_SESION";
        public readonly static string CodigoUsuario = "USUARIO_SESION";
        public readonly static string DescripcionUsuario = "DESCRIPCION_USUARIO_SESION";
    }
}
