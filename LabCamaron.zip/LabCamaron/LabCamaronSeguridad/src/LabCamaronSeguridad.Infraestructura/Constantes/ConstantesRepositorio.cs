namespace LabCamaronSeguridad.Infraestructura.Constantes
{
    public static class ConstantesRepositorio
    {
        public static readonly string CodigoTransaccion = "@CodigoTransaccion";
        public static readonly string MensajeTransaccion = "@MensajeTransaccion";

        public static readonly string UsuarioSesion = "@UsuarioSesion";

        public static readonly int SizeCodigoTransaccion = 5;
        public static readonly int SizeMensajeTransaccion = 250;

        public static readonly string SplitId = "id";
    }
}