namespace LabCamaronSeguridad.Infraestructura.Modelo.Token
{
    public class JwtModel(string token, string refreshToken)
    {
        public string Token { get; } = token;
        public string RefreshToken { get; } = refreshToken;
    }
}