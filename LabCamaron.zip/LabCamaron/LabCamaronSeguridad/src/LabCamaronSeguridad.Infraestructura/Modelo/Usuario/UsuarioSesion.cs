namespace LabCamaronSeguridad.Infraestructura.Modelo.Usuario
{
    public class UsuarioSesion
    {
        public string Codigo { get; set; } = null!;
        public string Descripcion { get; set; } = null!;
    }
}
