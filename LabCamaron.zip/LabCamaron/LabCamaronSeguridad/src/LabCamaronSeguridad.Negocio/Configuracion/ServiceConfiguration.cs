using LabCamaronSeguridad.Negocio.Configuracion.Login;
using LabCamaronSeguridad.Negocio.Configuracion.Rol;
using LabCamaronSeguridad.Negocio.Configuracion.Usuario;
using Microsoft.Extensions.DependencyInjection;

namespace LabCamaronSeguridad.Negocio.Configuracion
{
    public static class ServiceConfiguration
    {
        public static IServiceCollection AddNeConfiguracion(this IServiceCollection services)
        {
            services.AddScoped<INeLogin, NeLogin>();
            services.AddScoped<INeUsuario, NeUsuario>();
            services.AddScoped<INeRol, NeRol>();

            return services;
        }
    }
}