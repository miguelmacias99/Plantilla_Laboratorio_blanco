using LabCamaronSeguridad.Dto.Modelo.Configuracion.Rol;
using LabCamaronSeguridad.Infraestructura.Modelo;
using static LabCamaronSeguridad.Dto.Modelo.Configuracion.Rol.RolDto;

namespace LabCamaronSeguridad.Negocio.Configuracion.Rol
{
    public interface INeRol
    {
        Task<RespuestaConsultaRolDto> ConsultarPorId(ConsultarRol consultar);
        Task<RespuestaConsultaRolesDto> ConsultarTodos(ConsultarTodosRol consultar);
        Task<RespuestaGenericaDto> Crear(CrearRol crear);
        Task<RespuestaGenericaDto> Actualizar(ActualizarRol actualizar);
        Task<RespuestaGenericaDto> Eliminar(EliminarRol eliminar);
        Task<RespuestaConsultaPermisosRolDto> ConsultarPermisos(PermisoRolDto.Consultar consultar);
        Task<RespuestaGenericaDto> ActualizarPermisos(PermisoRolDto.Actualizar actualizar);
    }
}