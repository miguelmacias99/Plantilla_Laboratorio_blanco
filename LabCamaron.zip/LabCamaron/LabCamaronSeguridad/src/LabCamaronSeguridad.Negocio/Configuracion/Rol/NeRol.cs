using LabCamaronSeguridad.Dto.Modelo.Configuracion.Rol;
using LabCamaronSeguridad.Entidad.Interfaz;
using LabCamaronSeguridad.Infraestructura.Modelo;
using LabCamaronSeguridad.Infraestructura.Utilidades.Generico;
using LabCamaronSeguridad.Infraestructura.Utilidades.Logger;
using LabCamaronSeguridad.Infraestructura.Utilidades.Mapeador;
using static LabCamaronSeguridad.Dto.Modelo.Configuracion.Rol.RolDto;
using EntidadRol = LabCamaronSeguridad.Entidad.Modelo.Configuracion.Rol;
using EntidadPermisoRol = LabCamaronSeguridad.Entidad.Modelo.Configuracion.PermisoRol;
using LabCamaronSeguridad.Infraestructura.Services.Redis;
using LabCamaronSeguridad.Infraestructura.Constantes;

namespace LabCamaronSeguridad.Negocio.Configuracion.Rol
{
    internal class NeRol(IUnidadTrabajo unidadTrabajo, IRedisCacheService redisCache) : INeRol
    {
        private readonly IUnidadTrabajo unidadTrabajo = unidadTrabajo;
        private readonly IRedisCacheService redisCache = redisCache;

        public async Task<RespuestaGenericaDto> Actualizar(ActualizarRol actualizar)
        {
            try
            {
                // Validamos la entrada al servicio
                var (respuesta, esValido) = ValidarDataAnnotation.Validar(actualizar);
                if (!esValido) return respuesta;

                // Procesamos la solicitud
                var rol = actualizar.Mapear<EntidadRol.Actualizar>();
                var respuestaActualizar = await unidadTrabajo
                    .Roles
                    .ActualizarRol(rol);

                return respuestaActualizar;
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, actualizar);
                return RespuestaGenericaDto.Excepcion();
            }
        }

        public async Task<RespuestaGenericaDto> ActualizarPermisos(PermisoRolDto.Actualizar actualizar)
        {
            try
            {
                // Validamos la entrada al servicio
                var (respuesta, esValido) = ValidarDataAnnotation.Validar(actualizar);
                if (!esValido) return respuesta;

                // Procesamos la solicitud
                var detallesPermisos = actualizar.DetallePermisos.Mapear<List<EntidadPermisoRol.Actualizar>>();
                var respuestaActualizar = await unidadTrabajo
                    .Roles
                    .ActualizarPermisosRol(actualizar.Codigo!, detallesPermisos);

                if (respuesta.EsExitosa)
                {
                    await redisCache.EliminarClavesPorPatronAsync(ConstantesRedis.PrefijoPermisos);
                    await redisCache.EliminarClavesPorPatronAsync(ConstantesRedis.PrefijoDetallesPermisos);
                }

                return respuestaActualizar;
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, actualizar);
                return RespuestaGenericaDto.Excepcion();
            }
        }

        public async Task<RespuestaConsultaPermisosRolDto> ConsultarPermisos(PermisoRolDto.Consultar consultar)
        {
            try
            {
                // Validamos la entrada al servicio
                var (respuesta, esValido) = ValidarDataAnnotation.Validar(consultar);
                if (!esValido) return new(respuesta);

                // Procesamos la solicitud
                var detallesPermiso = await unidadTrabajo
                    .Roles
                    .ObtenerPermisosRol(consultar.Codigo!);

                var consultaRol = await unidadTrabajo
                    .Roles
                    .ObtenerRol(consultar.Codigo!);

                // Validamos si el rol existe
                if (consultaRol is null) return new(RespuestaGenericaDto.ErrorComun("El rol seleccionado no existe"));

                // Agrupamos los detalles de permisos
                var modulos = detallesPermiso
                    .GroupBy(e => new
                    {
                        e.OrdenModulo,
                        e.NombreModulo
                    })
                    .Select(x => new PermisoRolDto.Modulo()
                    {
                        OrdenModulo = x.Key.OrdenModulo,
                        NombreModulo = x.Key.NombreModulo,
                        Menus = x.GroupBy(y => new
                        {
                            y.OrdenMenu,
                            y.CodigoMenu,
                            y.NombreMenu
                        })
                         .Select(y => new PermisoRolDto.Menu
                         {
                             CodigoMenu = y.Key.CodigoMenu,
                             OrdenMenu = y.Key.OrdenMenu,
                             NombreMenu = y.Key.NombreMenu,
                             MenuAcciones = y.GroupBy(z => new
                             {
                                 z.IdMenuAccion,
                                 z.OrdenAccion,
                                 z.CodigoAccion,
                                 z.NombreAccion,
                                 z.DescripcionAccion,
                                 z.TienePermiso
                             })
                             .Select(z => new PermisoRolDto.MenuAccion
                             {
                                 IdMenuAccion = z.Key.IdMenuAccion,
                                 OrdenAccion = z.Key.OrdenAccion,
                                 CodigoAccion = z.Key.CodigoAccion,
                                 NombreAccion = z.Key.NombreAccion,
                                 DescripcionAccion = z.Key.DescripcionAccion,
                                 TienePermiso = z.Key.TienePermiso
                             }).ToList()
                         }).ToList(),
                    }).ToList();

                // retornamos la respuesta
                return new()
                {
                    Respuesta = RespuestaGenericaDto.ExitoComun(),
                    Permisos = new()
                    {
                        CodigoRol = consultaRol.Codigo,
                        NombreRol = consultaRol.Nombre,
                        Modulos = modulos
                    },
                };
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, consultar);
                return new(RespuestaGenericaDto.Excepcion());
            }
        }

        public async Task<RespuestaConsultaRolDto> ConsultarPorId(ConsultarRol consultar)
        {
            try
            {
                // Validamos la entrada al servicio
                var (respuesta, esValido) = ValidarDataAnnotation.Validar(consultar);
                if (!esValido) return new(respuesta);

                var rol = await unidadTrabajo
                    .Roles
                    .ObtenerRol(consultar.Codigo!);

                if (rol is null) return new(RespuestaGenericaDto.ErrorComun("El rol no existe"));

                return new()
                {
                    Respuesta = RespuestaGenericaDto.ExitoComun(),
                    Rol = rol.Mapear<RolDto>()
                };
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, consultar);
                return new(RespuestaGenericaDto.Excepcion());
            }
        }

        public async Task<RespuestaConsultaRolesDto> ConsultarTodos(ConsultarTodosRol consultar)
        {
            try
            {
                // Validamos la entrada al servicio
                var (respuesta, esValido) = ValidarDataAnnotation.Validar(consultar);
                if (!esValido) return new(respuesta);

                var roles = await unidadTrabajo
                    .Roles
                    .ObtenerRoles(consultar.SoloActivos);

                return new()
                {
                    Respuesta = RespuestaGenericaDto.ExitoComun(),
                    Roles = roles.Mapear<List<RolDto>>(),
                };
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex);
                return new(RespuestaGenericaDto.Excepcion());
            }
        }

        public async Task<RespuestaGenericaDto> Crear(CrearRol crear)
        {
            try
            {
                // Validamos la entrada al servicio
                var (respuesta, esValido) = ValidarDataAnnotation.Validar(crear);
                if (!esValido) return respuesta;

                // Procesamos la solicitud
                var rol = crear.Mapear<EntidadRol.Crear>();
                var crearRol = await unidadTrabajo
                    .Roles
                    .CrearRol(rol);

                return crearRol.respuesta;
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, crear);
                return RespuestaGenericaDto.Excepcion();
            }
        }

        public async Task<RespuestaGenericaDto> Eliminar(EliminarRol eliminar)
        {
            try
            {
                // Validamos la entrada al servicio
                var (respuesta, esValido) = ValidarDataAnnotation.Validar(eliminar);
                if (!esValido) return respuesta;

                // Procesamos la solicitud
                var respuestaEliminar = await unidadTrabajo
                    .Roles
                    .EliminarRol(eliminar.Codigo!);

                return respuestaEliminar;
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, eliminar);
                return RespuestaGenericaDto.Excepcion();
            }
        }
    }
}