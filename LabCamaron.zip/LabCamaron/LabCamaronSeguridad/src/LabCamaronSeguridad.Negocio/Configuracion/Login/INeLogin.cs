using LabCamaronSeguridad.Dto.Modelo.Configuracion.Login;

namespace LabCamaronSeguridad.Negocio.Configuracion.Login
{
    public interface INeLogin
    {
        Task<RespuestaLoginDto> Login(LoginDto login);
        Task<RespuestaAutorizacionAccionDto> AutorizarAccion(DetallePermisoDto.AutorizarAccion autorizar);
        Task<RespuestaPermisosDto> ObtenerPermisosSesion(DetallePermisoDto.ConsultarPermisos consultar);
    }
}