using LabCamaronSeguridad.Dto.Modelo.Configuracion.Login;
using LabCamaronSeguridad.Entidad.Interfaz;
using LabCamaronSeguridad.Entidad.Modelo.Configuracion;
using LabCamaronSeguridad.Infraestructura.Constantes;
using LabCamaronSeguridad.Infraestructura.Modelo;
using LabCamaronSeguridad.Infraestructura.Services.Redis;
using LabCamaronSeguridad.Infraestructura.Services.Sesion;
using LabCamaronSeguridad.Infraestructura.Services.Token;
using LabCamaronSeguridad.Infraestructura.Utilidades.Encriptacion;
using LabCamaronSeguridad.Infraestructura.Utilidades.Generico;
using LabCamaronSeguridad.Infraestructura.Utilidades.Logger;
using LabCamaronSeguridad.Infraestructura.Utilidades.Mapeador;
using LabCamaronSeguridad.Negocio.Configuracion.Usuario;
using Serilog;
using static LabCamaronSeguridad.Dto.Modelo.Configuracion.Login.PermisoUsuarioDto;

namespace LabCamaronSeguridad.Negocio.Configuracion.Login
{
    public class NeLogin(IUnidadTrabajo unidadTrabajo, IJwtService jwtService,
        IRedisCacheService redisCache, ISesionManager sesionManager) : INeLogin
    {
        private readonly IUnidadTrabajo unidadTrabajo = unidadTrabajo;
        private readonly IJwtService jwtService = jwtService;
        private readonly IRedisCacheService redisCache = redisCache;
        private readonly ISesionManager sesionManager = sesionManager;

        public async Task<RespuestaLoginDto> Login(LoginDto login)
        {
            try
            {
                // Validamos la entrada al servicio
                var (respuesta, esValido) = ValidarDataAnnotation.Validar(login);
                if (!esValido) return new(respuesta);

                // Hacemos las validaciones al negocio
                var usuario = await unidadTrabajo
                    .Usuarios
                    .ObtenerUsuario(login.Usuario!);

                if ((usuario == null) || !usuario.Activo)
                    return new(RespuestaGenericaDto.ErrorComun("El usuario no existe o está inactivo"));

                if (!ContraseniasUtil.VerificarContrasenia(login.Contrasenia!, usuario.HashContrasenia, usuario.SaltContrasenia))
                    return new(RespuestaGenericaDto.ErrorComun("El usuario/contraseña no es correcto"));

                // Preparamos consulta de permisos y perfiles de ese usuario
                var permisos = await unidadTrabajo
                    .Usuarios
                    .ObtenerPermisos(usuario.Id);
                var permisosDto = permisos.Mapear<PermisoUsuarioDto>();

                var roles = await unidadTrabajo
                    .Usuarios
                    .ObtenerRolesUsuario(usuario.Id);
                permisosDto.Roles = roles.ToList().Mapear<List<RolDto>>();

                var usuarioDto = usuario.Mapear<UsuarioDto>();
                permisosDto.Usuario = usuarioDto;

                // guardamos los permisos del usuario en caché
                var identificadorSesion = Guid.NewGuid().ToString();
                await redisCache.GuardarCache(ObtenerClaveUsuario(identificadorSesion), usuarioDto);
                await redisCache.GuardarCache(ObtenerClaveDetallesPermisos(identificadorSesion), PrepararDetallesPermisos(permisos));
                await redisCache.GuardarCache(ObtenerClavePermisos(identificadorSesion), permisosDto);

                return new()
                {
                    Respuesta = RespuestaGenericaDto.ExitoComun(),
                    IdentificadorSesion = identificadorSesion,
                    Permisos = permisosDto,
                    Jwt = jwtService.GenerateJwtToken(new()
                    {
                        Codigo = usuario.Codigo,
                        Descripcion = usuario.Descripcion,
                    })
                };
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, login);
                return new(RespuestaGenericaDto.Excepcion());
            }
        }

        public async Task<RespuestaPermisosDto> ObtenerPermisosSesion(DetallePermisoDto.ConsultarPermisos consultar)
        {
            try
            {
                // Validamos la entrada al servicio
                var (respuesta, esValido) = ValidarDataAnnotation.Validar(consultar);
                if (!esValido) return new(respuesta);

                var usuarioDto = await redisCache.ObtenerCache<UsuarioDto>(ObtenerClaveUsuario(consultar.IdentificadorSesion!));
                if (usuarioDto is null)
                {
                    return new(new(Servidor.SesionInvalida, "La sesión ha caducado"));
                }

                var permisosDto = await redisCache.ObtenerCache<PermisoUsuarioDto>(ObtenerClavePermisos(consultar.IdentificadorSesion!));
                if (permisosDto is null)
                {
                    var permisos = await unidadTrabajo
                        .Usuarios
                        .ObtenerPermisos(usuarioDto.Id);
                    permisosDto = permisos.Mapear<PermisoUsuarioDto>();

                    await redisCache.GuardarCache(ObtenerClaveDetallesPermisos(consultar.IdentificadorSesion!), PrepararDetallesPermisos(permisos));
                    await redisCache.GuardarCache(ObtenerClavePermisos(consultar.IdentificadorSesion!), permisosDto);
                }

                return new()
                {
                    Respuesta = RespuestaGenericaDto.ExitoComun(),
                    PermisoUsuario = permisosDto
                };
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, consultar);
                return new(RespuestaGenericaDto.Excepcion());
            }
        }

        private static string ObtenerClaveUsuario(string sesion)
        {
            return $"{ConstantesRedis.PrefijoUsuario}{sesion}";
        }
        private static string ObtenerClaveDetallesPermisos(string sesion)
        {
            return $"{ConstantesRedis.PrefijoDetallesPermisos}{sesion}";
        }
        private static string ObtenerClavePermisos(string sesion)
        {
            return $"{ConstantesRedis.PrefijoPermisos}{sesion}";
        }

        public async Task<RespuestaAutorizacionAccionDto> AutorizarAccion(DetallePermisoDto.AutorizarAccion autorizar)
        {
            try
            {
                // Validamos la entrada al servicio
                var (respuesta, esValido) = ValidarDataAnnotation.Validar(autorizar);
                if (!esValido) return new(respuesta);

                bool tieneAutorizacion = false;
                var usuario = sesionManager.ObtenerUsuarioSesion();
                var permisosDto = await redisCache
                    .ObtenerCache<List<DetallePermisoDto>>(ObtenerClaveDetallesPermisos(autorizar.IdentificadorSesion!));
                
                // Si existe un caché, validamos la acción desde ahí
                if (permisosDto is null)
                {
                    var permisos = await unidadTrabajo
                        .Usuarios
                        .ObtenerDetallesPermisosUsuario(usuario.Codigo);

                    permisosDto = permisos.Mapear<List<DetallePermisoDto>>();

                    await redisCache.GuardarCache(ObtenerClaveDetallesPermisos(autorizar.IdentificadorSesion!), permisosDto);
                }

                tieneAutorizacion = permisosDto
                    .Exists(e => e.CodigoMenu == autorizar.CodigoMenu && e.CodigoPermiso == autorizar.CodigoPermiso);

                return new()
                {
                    Respuesta = RespuestaGenericaDto.ExitoComun(),
                    TieneAutorizacion = tieneAutorizacion,
                };
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, autorizar);
                return new(RespuestaGenericaDto.Excepcion());
            }
        }

        private static List<DetallePermisoDto> PrepararDetallesPermisos(PermisoUsuario permisos)
        {
            var retorno = new List<DetallePermisoDto>();

            permisos.Modulos.ForEach(modulo =>
            {
                modulo.Menus.ForEach(menu =>
                {
                    var detallesPermiso = menu.Permisos.Select(e => new DetallePermisoDto()
                    {
                        CodigoMenu = menu.Codigo,
                        CodigoPermiso = e.Codigo,
                    });

                    retorno.AddRange(detallesPermiso);
                });
            });

            return retorno;
        }
    }
}