using LabCamaronSeguridad.Dto.Modelo.Configuracion.Usuario;
using LabCamaronSeguridad.Entidad.Interfaz;
using LabCamaronSeguridad.Infraestructura.Modelo;
using LabCamaronSeguridad.Infraestructura.Utilidades.Encriptacion;
using LabCamaronSeguridad.Infraestructura.Utilidades.Generico;
using LabCamaronSeguridad.Infraestructura.Utilidades.Logger;
using LabCamaronSeguridad.Infraestructura.Utilidades.Mapeador;
using static LabCamaronSeguridad.Dto.Modelo.Configuracion.Usuario.UsuarioDto;
using UsuarioEntidad = LabCamaronSeguridad.Entidad.Modelo.Configuracion.Usuario;

namespace LabCamaronSeguridad.Negocio.Configuracion.Usuario
{
    public class NeUsuario(IUnidadTrabajo unidadTrabajo) : INeUsuario
    {
        private readonly IUnidadTrabajo unidadTrabajo = unidadTrabajo;

        public async Task<RespuestaGenericaDto> ActualizarClaveUsuario(ActualizarClaveUsuario actualizar)
        {
            try
            {
                // Validamos la entrada al servicio
                var (respuesta, esValido) = ValidarDataAnnotation.Validar(actualizar);
                if (!esValido) return respuesta;

                // Hacemos las validaciones al negocio
                var usuario = await unidadTrabajo
                    .Usuarios
                    .ObtenerUsuario(actualizar.Codigo!);

                if ((usuario == null) || !usuario.Activo)
                    return RespuestaGenericaDto.ErrorComun("El usuario no existe o está inactivo");

                if (!usuario.ActualizarContrasenia)
                    return RespuestaGenericaDto.ErrorComun("Usuario no tiene habilitado el actualizar contraseña");

                // Revisar que la contraseña actual sea correcta
                if (!ContraseniasUtil.VerificarContrasenia(actualizar.ContraseniaActual!, usuario.HashContrasenia, usuario.SaltContrasenia))
                    return RespuestaGenericaDto.ErrorComun("La contraseña actual no es correcta");

                // Procesamos la solicitud
                var respuestaActualizar = await unidadTrabajo
                    .Usuarios
                    .ActualizarClaveUsuario(new(usuario.Id, actualizar.ContraseniaNueva));

                return respuestaActualizar;
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, actualizar);
                return RespuestaGenericaDto.Excepcion();
            }
        }

        public async Task<RespuestaGenericaDto> ActualizarRolesUsuario(ActualizarRolUsuario actualizar)
        {
            try
            {
                // Validamos la entrada al servicio
                var (respuesta, esValido) = ValidarDataAnnotation.Validar(actualizar);
                if (!esValido) return respuesta;

                // Procesamos la solicitud
                var rolesUsuario = actualizar.Roles!.Mapear<List<UsuarioEntidad.RolUsuario>>();
                var respuestaAct = await unidadTrabajo
                    .Usuarios
                    .ActualizarRolesUsuario(actualizar.Codigo, rolesUsuario);

                return respuestaAct;
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, actualizar);
                return RespuestaGenericaDto.Excepcion();
            }
        }

        public async Task<RespuestaGenericaDto> ActualizarUsuario(ActualizarUsuario actualizar)
        {
            try
            {
                // Validamos la entrada al servicio
                var (respuesta, esValido) = ValidarDataAnnotation.Validar(actualizar);
                if (!esValido) return respuesta;

                // Procesamos la solicitud
                var (respuestaAct, _) = await unidadTrabajo
                    .Usuarios
                    .ActualizarUsuario(new(actualizar.Codigo, actualizar.Descripcion));

                return respuestaAct;
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, actualizar);
                return RespuestaGenericaDto.Excepcion();
            }
        }

        public async Task<RespuestaConsultaUsuarioDto> ConsultarUsuario(ConsultarUsuario consultar)
        {
            try
            {
                // Validamos la entrada al servicio
                var (respuesta, esValido) = ValidarDataAnnotation.Validar(consultar);
                if (!esValido) return new(respuesta);

                // Procesamos la solicitud
                var usuario = await unidadTrabajo
                    .Usuarios
                    .ObtenerUsuario(consultar.Codigo);
                if (usuario is null)
                    return new(RespuestaGenericaDto.ErrorComun("El usuario no existe"));

                // Consultamos los roles del usuario
                var rolesUsuario = await unidadTrabajo
                    .Usuarios
                    .ObtenerRolesPermitidosUsuario(usuario.Id);

                var usuarioDto = usuario.Mapear<UsuarioDto>();
                usuarioDto.Roles = rolesUsuario.Mapear<List<RolPermitido>>();

                // retornamos la respuesta
                return new()
                {
                    Respuesta = RespuestaGenericaDto.ExitoComun(),
                    Usuario = usuarioDto
                };
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, consultar);
                return new(RespuestaGenericaDto.Excepcion());
            }
        }

        public async Task<RespuestaConsultaUsuariosDto> ConsultarUsuarios(ConsultarTodos consultar)
        {
            try
            {
                // Validamos la entrada al servicio
                var (respuesta, esValido) = ValidarDataAnnotation.Validar(consultar);
                if (!esValido) return new(respuesta);

                // Procesamos la solicitud
                var usuarios = await unidadTrabajo
                    .Usuarios
                    .ObtenerUsuarios(consultar.SoloActivos);

                return new()
                {
                    Respuesta = RespuestaGenericaDto.ExitoComun(),
                    Usuarios = usuarios!.Mapear<List<UsuarioDto>>()
                };

            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, consultar);
                return new(RespuestaGenericaDto.Excepcion());
            }
        }

        public async Task<RespuestaGenericaDto> CrearUsuario(CrearUsuario crear)
        {
            try
            {
                // Validamos la entrada al servicio
                var (respuesta, esValido) = ValidarDataAnnotation.Validar(crear);
                if (!esValido) return respuesta;

                // Procesamos la solicitud
                var (respuestaCrear, _) = await unidadTrabajo
                    .Usuarios
                    .CrearUsuario(new(crear.Codigo, crear.Contrasenia, crear.Descripcion, crear.ActualizarContrasenia));

                return respuestaCrear;
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, crear);
                return RespuestaGenericaDto.Excepcion();
            }
        }

        public async Task<RespuestaGenericaDto> EliminarUsuario(EliminarUsuario eliminar)
        {
            try
            {
                // Validamos la entrada al servicio
                var (respuesta, esValido) = ValidarDataAnnotation.Validar(eliminar);
                if (!esValido) return respuesta;

                return await unidadTrabajo
                    .Usuarios
                    .EliminarUsuario(eliminar.Codigo);
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, eliminar);
                return RespuestaGenericaDto.Excepcion();
            }
        }

        public async Task<RespuestaGenericaDto> ReestablecerContrasenia(ReestablecerContrasenia crear)
        {
            try
            {
                // Validamos la entrada al servicio
                var (respuesta, esValido) = ValidarDataAnnotation.Validar(crear);
                if (!esValido) return respuesta;

                // Procesamos la solicitud
                var usuario = await unidadTrabajo
                    .Usuarios
                    .ObtenerUsuario(crear.Codigo);
                if (usuario is null)
                    return RespuestaGenericaDto.ErrorComun("El usuario no existe");

                // Procesamos la solicitud
                var respuestaActualizar = await unidadTrabajo
                    .Usuarios
                    .ActualizarClaveUsuario(new(usuario.Id, usuario.Codigo));

                return respuestaActualizar;
            }
            catch (Exception ex)
            {
                LogUtils.LogError(ex, crear);
                return RespuestaGenericaDto.Excepcion();
            }
        }
    }
}