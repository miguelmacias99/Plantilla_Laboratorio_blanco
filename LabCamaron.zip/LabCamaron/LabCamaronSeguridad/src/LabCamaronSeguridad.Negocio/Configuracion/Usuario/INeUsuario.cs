using LabCamaronSeguridad.Dto.Modelo.Configuracion.Usuario;
using LabCamaronSeguridad.Infraestructura.Modelo;
using static LabCamaronSeguridad.Dto.Modelo.Configuracion.Usuario.UsuarioDto;

namespace LabCamaronSeguridad.Negocio.Configuracion.Usuario
{
    public interface INeUsuario
    {
        Task<RespuestaConsultaUsuariosDto> ConsultarUsuarios(ConsultarTodos consultar);
        Task<RespuestaConsultaUsuarioDto> ConsultarUsuario(ConsultarUsuario consultar);
        Task<RespuestaGenericaDto> CrearUsuario(CrearUsuario crear);
        Task<RespuestaGenericaDto> ActualizarUsuario(ActualizarUsuario actualizar);
        Task<RespuestaGenericaDto> ActualizarClaveUsuario(ActualizarClaveUsuario actualizar);
        Task<RespuestaGenericaDto> ReestablecerContrasenia(ReestablecerContrasenia crear);
        Task<RespuestaGenericaDto> ActualizarRolesUsuario(ActualizarRolUsuario actualizar);
        Task<RespuestaGenericaDto> EliminarUsuario(EliminarUsuario eliminar);
    }
}