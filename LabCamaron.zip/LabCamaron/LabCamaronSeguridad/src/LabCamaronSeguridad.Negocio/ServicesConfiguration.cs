using LabCamaronSeguridad.Negocio.Configuracion;
using Microsoft.Extensions.DependencyInjection;

namespace LabCamaronSeguridad.Negocio
{
    public static class ServicesConfiguration
    {
        public static IServiceCollection ConfigurarNegocio(this IServiceCollection services)
        {
            services.AddNeConfiguracion();

            return services;
        }
    }
}