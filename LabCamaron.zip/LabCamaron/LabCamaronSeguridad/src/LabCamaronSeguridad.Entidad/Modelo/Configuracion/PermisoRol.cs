﻿namespace LabCamaronSeguridad.Entidad.Modelo.Configuracion
{
    public class PermisoRol
    {
        public int OrdenModulo { get; set; }
        public string NombreModulo { get; set; } = string.Empty;
        public int OrdenMenu { get; set; }
        public string CodigoMenu { get; set; } = string.Empty;
        public string NombreMenu { get; set; } = string.Empty;
        public long IdMenuAccion { get; set; }
        public int OrdenAccion { get; set; }
        public string CodigoAccion { get; set; } = string.Empty;
        public string NombreAccion { get; set; } = string.Empty;
        public string DescripcionAccion { get; set; } = string.Empty;
        public bool TienePermiso { get; set; }

        public class Actualizar
        {
            public long IdMenuAccion { get; set; }
            public bool TienePermiso { get; set; }
        }
    }
}
