using LabCamaronSeguridad.Infraestructura.Utilidades.Encriptacion;

namespace LabCamaronSeguridad.Entidad.Modelo.Configuracion
{
    public class Usuario
    {
        public long Id { get; set; }
        public string Codigo { get; set; } = string.Empty;
        public string Descripcion { get; set; } = string.Empty;
        public string Tipo { get; set; } = string.Empty;
        public bool Activo { get; set; }
        public bool ActualizarContrasenia { get; set; }
        public DateTime? FechaValidezContrasenia { get; set; }
        public string HashContrasenia { get; set; } = string.Empty;
        public string SaltContrasenia { get; set; } = string.Empty;


        public class ActualizarClave
        {
            public long Id { set; get; }
            public string HashContrasenia { get; }
            public string SaltContrasenia { get; }

            public ActualizarClave(long id, string contrasenia)
            {
                Id = id;

                var (hash, salt) = ContraseniasUtil.EncriptarContrasenia(contrasenia);
                HashContrasenia = hash;
                SaltContrasenia = salt;
            }
        }

        public class Crear
        {
            public string Codigo { get; set; }
            public string Descripcion { get; set; }
            public string Tipo { get; set; }
            public bool ActualizarContrasenia { get; set; }
            public string HashContrasenia { get; }
            public string SaltContrasenia { get; }

            public Crear(string codigo, string contrasenia,
                string descripcion, bool actualizarContrasenia)
            {
                Codigo = codigo;
                Descripcion = descripcion;
                Tipo = "ESTAN"; // Aplicación de usuario estandar
                ActualizarContrasenia = actualizarContrasenia;

                var (hash, salt) = ContraseniasUtil.EncriptarContrasenia(contrasenia);
                HashContrasenia = hash;
                SaltContrasenia = salt;
            }
        }

        public class Actualizar(string codigo, string descripcion)
        {
            public string Codigo { get; set; } = codigo;
            public string Descripcion { get; set; } = descripcion;
        }

        public class RolUsuario
        {
            public long IdRol { get; set; }
            public bool TienePermiso { get; set; }
        }
    }
}