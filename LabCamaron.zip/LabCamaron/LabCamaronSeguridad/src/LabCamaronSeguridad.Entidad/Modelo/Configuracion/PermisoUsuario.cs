namespace LabCamaronSeguridad.Entidad.Modelo.Configuracion
{
    public class PermisoUsuario
    {
        public List<Modulo> Modulos { get; set; } = [];

        public class Modulo
        {
            public long Id { get; set; }
            public int Orden { get; set; }
            public string Codigo { get; set; } = string.Empty;
            public string Nombre { get; set; } = string.Empty;
            public string Descripcion { get; set; } = string.Empty;
            public string IconoModulo { get; set; } = string.Empty;
            public List<Menu> Menus { get; set; } = [];
        }

        public class Menu
        {
            public long Id { get; set; }
            public int Orden { get; set; }
            public string Codigo { get; set; } = string.Empty;
            public string Nombre { get; set; } = string.Empty;
            public string Descripcion { get; set; } = string.Empty;
            public string Controlador { get; set; } = string.Empty;
            public string IconoMenu { get; set; } = string.Empty;
            public string Accion { get; set; } = string.Empty;
            public bool Mostrar { get; set; }
            public List<Permiso> Permisos { get; set; } = [];
        }

        public class Permiso
        {
            public long Id { get; set; }
            public string Codigo { get; set; } = string.Empty;
            public string Nombre { get; set; } = string.Empty;
            public string Descripcion { get; set; } = string.Empty;
        }

        public class Rol
        {
            public long Id { get; set; }
            public string Codigo { get; set; } = string.Empty;
            public string Nombre { get; set; } = string.Empty;
            public string Descripcion { get; set; } = string.Empty;
        }

        public class RolPermitido
        {
            public long Id { get; set; }
            public string Codigo { get; set; } = string.Empty;
            public string Nombre { get; set; } = string.Empty;
            public string Descripcion { get; set; } = string.Empty;
            public bool TienePermiso { get; set; }
        }

        public class DetallePermiso
        {
            public string CodigoMenu { get; set; } = string.Empty;
            public string CodigoPermiso { get; set; } = string.Empty;
        }
    }
}