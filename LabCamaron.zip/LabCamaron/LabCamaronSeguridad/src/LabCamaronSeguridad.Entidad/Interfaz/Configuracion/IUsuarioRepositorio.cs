using LabCamaronSeguridad.Entidad.Modelo.Configuracion;
using LabCamaronSeguridad.Infraestructura.Modelo;
using static LabCamaronSeguridad.Entidad.Modelo.Configuracion.Usuario;

namespace LabCamaronSeguridad.Entidad.Interfaz.Configuracion
{
    public interface IUsuarioRepositorio
    {
        Task<Usuario?> ObtenerUsuario(string codigo);
        Task<IEnumerable<Usuario>?> ObtenerUsuarios(bool soloActivos);
        Task<(RespuestaGenericaDto respuesta, long id)> CrearUsuario(Crear crear);
        Task<(RespuestaGenericaDto respuesta, long id)> ActualizarUsuario(Actualizar actualizar);
        Task<RespuestaGenericaDto> ActualizarClaveUsuario(ActualizarClave actualizar);
        Task<RespuestaGenericaDto> ActualizarRolesUsuario(string codigoUsuario, IEnumerable<RolUsuario> rolesUsuario);
        Task<RespuestaGenericaDto> EliminarUsuario(string codigoUsuario);
        Task<PermisoUsuario> ObtenerPermisos(long idUsuario);
        Task<IEnumerable<PermisoUsuario.Rol>> ObtenerRolesUsuario(long idUsuario);
        Task<IEnumerable<PermisoUsuario.RolPermitido>> ObtenerRolesPermitidosUsuario(long idUsuario);
        Task<IEnumerable<PermisoUsuario.DetallePermiso>> ObtenerDetallesPermisosUsuario(string codigoUsuario);
    }
}