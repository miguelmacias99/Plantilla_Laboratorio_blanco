using LabCamaronSeguridad.Entidad.Modelo.Configuracion;
using LabCamaronSeguridad.Infraestructura.Modelo;
using static LabCamaronSeguridad.Entidad.Modelo.Configuracion.Rol;

namespace LabCamaronSeguridad.Entidad.Interfaz.Configuracion
{
    public interface IRolRepositorio
    {
        Task<Rol?> ObtenerRol(string codigo);
        Task<(RespuestaGenericaDto respuesta, long id)> CrearRol(Crear crear);
        Task<RespuestaGenericaDto> ActualizarRol(Actualizar actualizar);
        Task<RespuestaGenericaDto> EliminarRol(string codigo);
        Task<IEnumerable<Rol>> ObtenerRoles(bool soloActivos);        
        Task<IEnumerable<PermisoRol>> ObtenerPermisosRol(string codigoRol);
        Task<RespuestaGenericaDto> ActualizarPermisosRol(string codigoRol, IEnumerable<PermisoRol.Actualizar> permisos);
    }
}