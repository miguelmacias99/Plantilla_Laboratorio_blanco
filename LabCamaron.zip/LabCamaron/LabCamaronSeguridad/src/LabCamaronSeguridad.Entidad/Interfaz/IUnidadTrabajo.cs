using LabCamaronSeguridad.Entidad.Interfaz.Configuracion;

namespace LabCamaronSeguridad.Entidad.Interfaz
{
    public interface IUnidadTrabajo
    {
        void Begin();

        void Commit();

        void Rollback();

        public IRolRepositorio Roles { get; }
        public IUsuarioRepositorio Usuarios { get; }
    }
}