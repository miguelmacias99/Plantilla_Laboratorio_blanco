namespace LabCamaronGateway.ApiExterna.Constantes
{
    public static class ConstantesSesion
    {
        public static readonly string Bearer = "Bearer ";
        public static readonly string Authorization = "Authorization";
        public static readonly string Identificador = "IDENTIFICADOR_SESION";
        public static readonly string CodigoUsuario = "USUARIO_SESION";
        public static readonly string DescripcionUsuario = "DESCRIPCION_USUARIO_SESION";
    }
}