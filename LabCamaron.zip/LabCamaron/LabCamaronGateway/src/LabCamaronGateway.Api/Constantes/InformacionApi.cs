namespace LabCamaronGateway.ApiExterna.Constantes
{
    public static class InformacionApi
    {
        public static string Nombre { get; set; } = null!;
        public static readonly string IdentificadoApi = "D33A2464-7681-40CD-8D3A-9AF6BB610A27";
    }
}