using LabCamaronGateway.ApiExterna.Constantes;
using System.IdentityModel.Tokens.Jwt;

namespace LabCamaronGateway.ApiExterna.Middleware
{
    public class JwtMiddleware(RequestDelegate next)
    {
        private readonly RequestDelegate _next = next;

        public async Task Invoke(HttpContext context)
        {
            if (context.Request.Path == "/health-check")
            {
                await context.Response.WriteAsync("ready");
                return;
            }

            var token = context.Request.Headers.Authorization.FirstOrDefault()?.Split(" ")[^1];
            if (!string.IsNullOrEmpty(token))
            {
                try
                {
                    var tokenHandler = new JwtSecurityTokenHandler();
                    var securityToken = (JwtSecurityToken)tokenHandler.ReadToken(token);
                    var claimValue = securityToken.Claims.FirstOrDefault(c => c.Type == ConstantesSesion.CodigoUsuario)?.Value;

                    if (string.IsNullOrEmpty(claimValue))
                    {
                        context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                        return;
                    }
                }
                catch
                {
                    context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                    return;
                }
            }

            await _next(context);
        }
    }
}