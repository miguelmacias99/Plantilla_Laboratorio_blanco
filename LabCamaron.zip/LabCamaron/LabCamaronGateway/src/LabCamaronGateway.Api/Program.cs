using LabCamaronGateway.ApiExterna.Constantes;
using LabCamaronGateway.ApiExterna.Extensiones;
using LabCamaronGateway.ApiExterna.Middleware;
using Ocelot.DependencyInjection;
using Ocelot.Middleware;
using System.Reflection;

var builder = WebApplication.CreateBuilder(args);
builder.Configuration
    .AddJsonFile("ocelot.json")
    .AddJsonFile("MicroservicioSeguridades.ocelot.json")
    //.AddJsonFile("MicroservicioProductos.ocelot.json")
    ;

InformacionApi.Nombre = Assembly.GetExecutingAssembly().GetName().Name!;

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.ConfigurarSerilog(builder);
builder.Services.ConfigurarAutenticacion(builder.Configuration);
builder.Services.AddOcelot(builder.Configuration);

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.MapGet("/health-check", () => { });

app.UseRouting();
app.UseHttpsRedirection();
app.UseAuthorization();
app.UseAuthentication();
app.UseMiddleware<JwtMiddleware>();
app.UseMiddleware<LogMiddleware>();
app.AgregarOperacionesApi(builder.Environment.EnvironmentName);

await app.UseOcelot();
await app.RunAsync();